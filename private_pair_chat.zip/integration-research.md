# ملاحظات تكامل المكالمات والإشعارات

## LiveKit Cloud للمكالمات

تتطلب مكالمات Expo مع LiveKit حزم LiveKit React Native ومكوّن Expo الإضافي وWebRTC، كما أنها تتطلب بناء جوال مخصصًا ولا تعمل في Expo Go بسبب الشيفرة الأصلية المطلوبة. يجب أن يستخرج الخادم رموز JWT قصيرة العمر من مفتاح API وسرّه؛ لا يوضع سر LiveKit في العميل. يمكن تفعيل E2EE لمسارات الصوت والصورة عبر مفتاح مشترك يُوزّع بين طرفي المحادثة عبر القناة المشفرة القائمة.

- https://docs.livekit.io/transport/sdk-platforms/expo/
- https://docs.livekit.io/frontends/build/authentication/
- https://docs.livekit.io/transport/encryption/start/

## Expo Push Notifications

تحتاج الإشعارات إلى إذن المستخدم ورمز Expo Push Token مسجل لدى الخادم، وإضافة `expo-notifications` إلى إعدادات التطبيق. لا توضع رسالة المحادثة أو مفتاح التشفير في حمولة الإشعار؛ تقتصر إشعارات «همس» على نوع الحدث ومعرّف جلسة محدود. يحتاج Android إعداد FCM V1 ومفتاح حساب خدمة مرفوعًا إلى اعتماد Expo/EAS وملف `google-services.json`. يحتاج iOS إلى حساب Apple Developer ومفتاح APNs. يلزم بناء جوال مخصص لاختبار الإشعارات البعيدة.

- https://docs.expo.dev/push-notifications/push-notifications-setup/
- https://docs.expo.dev/push-notifications/fcm-credentials/
- https://docs.expo.dev/push-notifications/sending-notifications/
