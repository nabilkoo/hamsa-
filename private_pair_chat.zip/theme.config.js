/** @type {const} */
const themeColors = {
  primary: { light: '#29B6D8', dark: '#29B6D8' },
  background: { light: '#0A1420', dark: '#0A1420' },
  surface: { light: '#132537', dark: '#132537' },
  foreground: { light: '#F3F8FC', dark: '#F3F8FC' },
  muted: { light: '#9FB5C6', dark: '#9FB5C6' },
  border: { light: '#234157', dark: '#234157' },
  success: { light: '#43D3A0', dark: '#43D3A0' },
  warning: { light: '#F4B860', dark: '#F4B860' },
  error: { light: '#FF8E98', dark: '#FF8E98' },
};

module.exports = { themeColors };
