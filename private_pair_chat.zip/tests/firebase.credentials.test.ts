import { describe, expect, it } from "vitest";

import { getFirebaseAccessToken } from "../server/firebase";

describe("اعتماد Firebase", () => {
  it("يحصل على رمز OAuth قصير العمر لإرسال إشعارات FCM", async () => {
    const result = await getFirebaseAccessToken();
    expect(result.projectId).toBe("hamas-notifications");
    expect(result.accessToken.length).toBeGreaterThan(30);
    expect(result.expiresIn).toBeGreaterThan(0);
  }, 20_000);
});
