import { describe, expect, it } from "vitest";

import { hasLongPendingMessage, isMessageLongPending, PENDING_MESSAGE_THRESHOLD_MS, removePendingOutgoingMessage } from "../lib/chat/message-status";

describe("تنبيه الرسائل المعلقة", () => {
  const now = 1_000_000;

  it("يظهر فقط للرسالة الصادرة التي تجاوزت مدة الانتظار دون تسليم", () => {
    const pending = { id: "m1", direction: "outgoing" as const, text: "خاص", sentAt: now - PENDING_MESSAGE_THRESHOLD_MS, status: "sent" as const };
    expect(isMessageLongPending(pending, now)).toBe(true);
    expect(
      hasLongPendingMessage(
        [pending],
        now,
      ),
    ).toBe(true);
  });

  it("يختفي عند التسليم أو القراءة ولا يظهر للرسائل الواردة أو الحديثة", () => {
    expect(
      hasLongPendingMessage(
        [
          { id: "m1", direction: "outgoing", text: "خاص", sentAt: now - PENDING_MESSAGE_THRESHOLD_MS - 1, status: "delivered" },
          { id: "m2", direction: "outgoing", text: "خاص", sentAt: now - PENDING_MESSAGE_THRESHOLD_MS - 1, status: "read" },
          { id: "m3", direction: "incoming", text: "خاص", sentAt: now - PENDING_MESSAGE_THRESHOLD_MS - 1, status: "received" },
          { id: "m4", direction: "outgoing", text: "خاص", sentAt: now - 1, status: "sent" },
        ],
        now,
      ),
    ).toBe(false);
  });

  it("يحذف فقط الرسالة الصادرة التي لم يُؤكَّد تسليمها", () => {
    const sent = { id: "sent", direction: "outgoing" as const, text: "خاص", sentAt: now, status: "sent" as const };
    const delivered = { id: "delivered", direction: "outgoing" as const, text: "خاص", sentAt: now, status: "delivered" as const };
    const messages = [sent, delivered];

    expect(removePendingOutgoingMessage(messages, sent.id)).toEqual([delivered]);
    expect(removePendingOutgoingMessage(messages, delivered.id)).toBe(messages);
  });
});
