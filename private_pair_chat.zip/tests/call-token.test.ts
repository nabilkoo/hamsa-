import { decodeJwt } from "jose";
import { describe, expect, it } from "vitest";

import { createCallToken } from "../server/call-token";

describe("رمز مكالمة LiveKit", () => {
  it("يقيّد الرمز بغرفة اتصال واحدة ويمنحه مدة قصيرة", async () => {
    const result = await createCallToken({
      roomId: "privateRoom_123456789",
      callId: "privateCall_123456789",
      participantId: "participant_123456789",
    });
    const payload = decodeJwt(result.token) as { video?: { room?: string; roomJoin?: boolean }; exp?: number };
    expect(result.serverUrl).toMatch(/^wss:\/\//);
    expect(payload.video?.room).toBe("hamas-privateRoom_123456789-privateCall_123456789");
    expect(payload.video?.roomJoin).toBe(true);
    expect(payload.exp).toBeGreaterThan(Math.floor(Date.now() / 1000));
    expect(payload.exp).toBeLessThanOrEqual(Math.floor(Date.now() / 1000) + 600);
  });
});
