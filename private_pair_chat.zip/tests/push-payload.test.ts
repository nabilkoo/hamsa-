import { describe, expect, it } from "vitest";

import { createIncomingCallMessage } from "../server/push";

describe("تنبيه المكالمة", () => {
  it("لا يتضمن نص الرسالة أو معرّف الغرفة أو مفتاح تشفير", async () => {
    const payload = createIncomingCallMessage("fcm_registration_token_very_long_12345");
    expect(payload).toMatchObject({ message: { notification: { title: "همس", body: "لديك مكالمة واردة" }, data: { kind: "incoming-call" } } });
    expect(JSON.stringify(payload)).not.toContain("privateRoom_123456789");
    expect(JSON.stringify(payload)).not.toContain("encryptionKey");
  });
});
