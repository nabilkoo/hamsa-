import { describe, expect, it, vi } from "vitest";

vi.mock("react-native-get-random-values", () => ({}));

import { createPinCredential, isValidPin, verifyPin } from "../lib/app-lock/pin";

describe("قفل التطبيق برمز PIN", () => {
  it("يقبل رمزًا رقميًا من 4 إلى 8 أرقام فقط", () => {
    expect(isValidPin("1234")).toBe(true);
    expect(isValidPin("12345678")).toBe(true);
    expect(isValidPin("123")).toBe(false);
    expect(isValidPin("12ab")).toBe(false);
  });

  it("يتحقق من الرمز دون حفظه كنص ظاهر", () => {
    const credential = createPinCredential("482916");
    expect(credential.digest).not.toContain("482916");
    expect(verifyPin("482916", credential)).toBe(true);
    expect(verifyPin("482917", credential)).toBe(false);
  });
});
