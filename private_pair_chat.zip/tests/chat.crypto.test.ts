import { describe, expect, it, vi } from "vitest";

vi.mock("react-native-get-random-values", () => ({}));

import {
  createIdentity,
  createStorageKey,
  decryptFromPeer,
  decryptLocalValue,
  encryptForPeer,
  encryptLocalValue,
  makeSafetyNumber,
} from "../lib/chat/crypto";

describe("تشفير محادثة همس", () => {
  it("يفك الطرف المقصود الرسالة دون الطرف الآخر", () => {
    const first = createIdentity();
    const second = createIdentity();
    const outsider = createIdentity();
    const envelope = encryptForPeer("رسالة خاصة", first.secretKey, second.publicKey);

    expect(decryptFromPeer(envelope, second.secretKey, first.publicKey)).toBe("رسالة خاصة");
    expect(() => decryptFromPeer(envelope, outsider.secretKey, first.publicKey)).toThrow();
  });

  it("ينتج رقم أمان واحدًا للطرفين بغض النظر عن الترتيب", () => {
    const first = createIdentity();
    const second = createIdentity();

    expect(makeSafetyNumber(first.publicKey, second.publicKey)).toBe(
      makeSafetyNumber(second.publicKey, first.publicKey),
    );
  });

  it("يحفظ سجل الرسائل في غلاف مشفر لا يكشف النص", () => {
    const storageKey = createStorageKey();
    const messages = [{ id: "m-1", text: "لا تحفظ هذه الرسالة كنص ظاهر" }];
    const vault = encryptLocalValue(messages, storageKey);

    expect(vault.ciphertext).not.toContain(messages[0].text);
    expect(decryptLocalValue<typeof messages>(vault, storageKey)).toEqual(messages);
  });
});
