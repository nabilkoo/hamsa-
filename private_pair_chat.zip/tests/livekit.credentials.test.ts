import { SignJWT } from "jose";
import { describe, expect, it } from "vitest";

const livekitUrl = process.env.LIVEKIT_URL;
const apiKey = process.env.LIVEKIT_API_KEY;
const apiSecret = process.env.LIVEKIT_API_SECRET;

describe("اعتمادات LiveKit", () => {
  it("تُصدر رمزًا قصير العمر وتستدعي واجهة الغرف بنجاح", async () => {
    expect(livekitUrl).toMatch(/^wss:\/\//);
    expect(apiKey).toBeTruthy();
    expect(apiSecret).toBeTruthy();

    const token = await new SignJWT({ video: { roomList: true } })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(apiKey!)
      .setSubject("hamas-credentials-check")
      .setIssuedAt()
      .setExpirationTime("60s")
      .sign(new TextEncoder().encode(apiSecret!));
    const apiUrl = `${livekitUrl!.replace(/^wss:/, "https:")}/twirp/livekit.RoomService/ListRooms`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: "{}",
    });

    expect(response.ok, `LiveKit returned HTTP ${response.status}`).toBe(true);
  }, 20_000);
});
