import WebSocket from "ws";

const roomId = `RelaySmokeCheck${Date.now().toString(36)}`;
const endpoint = "ws://127.0.0.1:3000/api/relay";

function connect() {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(endpoint);
    const timeout = setTimeout(() => reject(new Error("Relay connection timed out")), 5000);
    socket.once("open", () => {
      clearTimeout(timeout);
      resolve(socket);
    });
    socket.once("error", reject);
  });
}

function nextMessage(socket) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Relay message timed out")), 5000);
    socket.once("message", (raw) => {
      clearTimeout(timeout);
      resolve(JSON.parse(raw.toString()));
    });
  });
}

const first = await connect();
const second = await connect();
try {
  first.send(JSON.stringify({ type: "hello", roomId }));
  second.send(JSON.stringify({ type: "hello", roomId }));
  await Promise.all([nextMessage(first), nextMessage(second)]);

  const received = nextMessage(second);
  const sample = { type: "signal", roomId, id: "signal-1", senderPublicKey: "public-key-smoke-check", nonce: "sample-nonce", ciphertext: "sample-ciphertext", sentAt: Date.now() };
  first.send(JSON.stringify(sample));
  const packet = await received;
  if (packet.type !== sample.type || packet.roomId !== roomId || packet.id !== sample.id || packet.ciphertext !== sample.ciphertext) {
    throw new Error("Relay did not preserve the transient packet");
  }

  const third = await connect();
  const rejected = new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Third peer was not rejected")), 5000);
    third.on("message", (raw) => {
      const message = JSON.parse(raw.toString());
      if (message.type === "error") {
        clearTimeout(timeout);
        resolve(message);
      }
    });
  });
  third.send(JSON.stringify({ type: "hello", roomId }));
  await rejected;
  third.close();
  console.log("Relay smoke test passed");
} finally {
  first.close();
  second.close();
}
