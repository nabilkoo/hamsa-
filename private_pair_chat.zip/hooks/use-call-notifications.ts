import { trpc } from "@/lib/trpc";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import { useCallback, useRef, useState } from "react";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

type NotificationState = "idle" | "enabling" | "enabled" | "unavailable" | "denied";

export function useCallNotifications(roomId?: string) {
  const register = trpc.calls.registerPushToken.useMutation();
  const remove = trpc.calls.removePushToken.useMutation();
  const notify = trpc.calls.notifyIncomingCall.useMutation();
  const tokenRef = useRef<string | null>(null);
  const [state, setState] = useState<NotificationState>("idle");
  const [reason, setReason] = useState<string | null>(null);

  const enableNotifications = useCallback(async () => {
    if (!roomId) return;
    if (Platform.OS === "web" || !Device.isDevice) {
      setState("unavailable");
      setReason("تحتاج إشعارات المكالمات إلى بناء جوال مُثبّت على جهاز فعلي.");
      return;
    }
    setState("enabling");
    setReason(null);
    try {
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("private-calls", {
          name: "مكالمات همس الخاصة",
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 250, 150, 250],
          lightColor: "#29B6D8",
          sound: "default",
        });
      }
      const existing = await Notifications.getPermissionsAsync();
      const permission = existing.granted ? existing : await Notifications.requestPermissionsAsync();
      if (!permission.granted) {
        setState("denied");
        setReason("لم يُمنح إذن الإشعارات. يمكنك تفعيله لاحقًا من إعدادات الهاتف.");
        return;
      }
      const token = String((await Notifications.getDevicePushTokenAsync()).data);
      if (token.length < 20) throw new Error("لم يُرجع الجهاز رمز FCM صالحًا بعد.");
      await register.mutateAsync({ roomId, token });
      tokenRef.current = token;
      setState("enabled");
    } catch (error) {
      setState("unavailable");
      setReason(error instanceof Error ? error.message : "تعذر تفعيل إشعارات المكالمات الآن.");
    }
  }, [register, roomId]);

  const sendIncomingCallNotice = useCallback(
    (targetRoomId: string) => notify.mutateAsync({ roomId: targetRoomId, excludeToken: tokenRef.current ?? undefined }),
    [notify],
  );

  const unregisterForRoom = useCallback(
    async (targetRoomId?: string) => {
      if (!targetRoomId || !tokenRef.current) return;
      await remove.mutateAsync({ roomId: targetRoomId, token: tokenRef.current });
      tokenRef.current = null;
      setState("idle");
    },
    [remove],
  );

  return { state, reason, enableNotifications, sendIncomingCallNotice, unregisterForRoom };
}
