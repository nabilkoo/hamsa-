import type { ChatMessage } from "./types";

export const PENDING_MESSAGE_THRESHOLD_MS = 20_000;

export function isMessageLongPending(message: ChatMessage, now: number) {
  return (
    message.direction === "outgoing" &&
    message.status === "sent" &&
    now - message.sentAt >= PENDING_MESSAGE_THRESHOLD_MS
  );
}

export function hasLongPendingMessage(messages: ChatMessage[], now: number) {
  return messages.some((message) => isMessageLongPending(message, now));
}

export function removePendingOutgoingMessage(messages: ChatMessage[], messageId: string) {
  const target = messages.find((message) => message.id === messageId);
  if (!target || target.direction !== "outgoing" || target.status !== "sent") return messages;
  return messages.filter((message) => message.id !== messageId);
}
