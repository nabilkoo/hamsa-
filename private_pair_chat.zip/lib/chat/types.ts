export type ConnectionState = "disconnected" | "connecting" | "connected";

export type ChatSession = {
  version: 1;
  roomId: string;
  ownPublicKey: string;
  ownSecretKey: string;
  peerPublicKey?: string;
  storageKey: string;
  invite: string;
  verified: boolean;
  createdAt: number;
};

export type ChatMessage = {
  id: string;
  direction: "incoming" | "outgoing";
  text: string;
  sentAt: number;
  status: "sent" | "delivered" | "read" | "received";
  readAt?: number;
};

export type InvitePayload = {
  v: 1;
  r: string;
  k: string;
};

export type HandshakePacket = {
  type: "handshake";
  roomId: string;
  publicKey: string;
};

export type MessagePacket = {
  type: "message";
  roomId: string;
  id: string;
  senderPublicKey: string;
  nonce: string;
  ciphertext: string;
  sentAt: number;
};

export type SignalPacket = {
  type: "signal";
  roomId: string;
  id: string;
  senderPublicKey: string;
  nonce: string;
  ciphertext: string;
  sentAt: number;
};

export type SignalPayload =
  | { kind: "typing"; active: boolean }
  | { kind: "delivered"; messageId: string }
  | { kind: "read"; messageId: string }
  | { kind: "call-invite"; callId: string; roomId: string; sentAt: number }
  | { kind: "call-cancel"; callId: string };

export type CallInvite = {
  callId: string;
  roomId: string;
  sentAt: number;
};

export type CallJoinDetails = {
  roomId: string;
  participantId: string;
  encryptionKey: string;
  callId: string;
};

export type RelayPacket = HandshakePacket | MessagePacket | SignalPacket;
