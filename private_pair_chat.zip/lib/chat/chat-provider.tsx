import { getApiBaseUrl } from "@/constants/oauth";
import { createContext, type PropsWithChildren, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import {
  createIdentity,
  createRoomId,
  createStorageKey,
  decryptFromPeer,
  deriveCallEncryptionKey,
  encryptForPeer,
  makeSafetyNumber,
} from "./crypto";
import { RelayClient } from "./relay";
import { removePendingOutgoingMessage } from "./message-status";
import { clearLocalChat, loadMessages, loadSession, saveMessages, saveSession } from "./storage";
import type { CallInvite, CallJoinDetails, ChatMessage, ChatSession, ConnectionState, InvitePayload, RelayPacket, SignalPayload } from "./types";

type ChatContextValue = {
  ready: boolean;
  session: ChatSession | null;
  messages: ChatMessage[];
  connection: ConnectionState;
  peerIsTyping: boolean;
  incomingCall: CallInvite | null;
  error: string | null;
  safetyNumber: string | null;
  createSession: () => Promise<void>;
  joinSession: (invite: string) => Promise<void>;
  sendMessage: (text: string) => Promise<void>;
  retryMessage: (messageId: string) => Promise<void>;
  deletePendingMessage: (messageId: string) => Promise<void>;
  setTyping: (isTyping: boolean) => void;
  markIncomingMessagesRead: () => Promise<void>;
  beginCall: () => CallJoinDetails;
  acceptIncomingCall: () => CallJoinDetails;
  dismissIncomingCall: () => void;
  endCall: (callId: string) => void;
  confirmSafetyNumber: () => Promise<void>;
  clearSession: () => Promise<void>;
  dismissError: () => void;
};

const ChatContext = createContext<ChatContextValue | null>(null);

function encodeInvite(payload: InvitePayload) {
  return `همس:${JSON.stringify(payload)}`;
}

function decodeInvite(input: string): InvitePayload {
  const raw = input.trim().replace(/^همس:/, "");
  const payload = JSON.parse(raw) as InvitePayload;
  if (
    payload.v !== 1 ||
    !/^[A-Za-z0-9_-]{16,64}$/.test(payload.r) ||
    typeof payload.k !== "string" ||
    payload.k.length < 40
  ) {
    throw new Error("دعوة الجلسة غير صالحة.");
  }
  return payload;
}

function makeMessageId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function ChatProvider({ children }: PropsWithChildren) {
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [connection, setConnection] = useState<ConnectionState>("disconnected");
  const [peerIsTyping, setPeerIsTyping] = useState(false);
  const [incomingCall, setIncomingCall] = useState<CallInvite | null>(null);
  const [error, setError] = useState<string | null>(null);
  const sessionRef = useRef<ChatSession | null>(null);
  const messagesRef = useRef<ChatMessage[]>([]);
  const relayRef = useRef<RelayClient | null>(null);
  const peerTypingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingStateRef = useRef(false);
  const lastTypingSignalAtRef = useRef(0);

  const updateSession = useCallback(async (nextSession: ChatSession) => {
    sessionRef.current = nextSession;
    setSession(nextSession);
    await saveSession(nextSession);
  }, []);

  const persistMessages = useCallback(async (nextMessages: ChatMessage[]) => {
    messagesRef.current = nextMessages;
    setMessages(nextMessages);
    if (sessionRef.current) await saveMessages(nextMessages, sessionRef.current.storageKey);
  }, []);

  const sendEncryptedSignal = useCallback((payload: SignalPayload) => {
    const activeSession = sessionRef.current;
    if (!activeSession?.peerPublicKey) return;
    try {
      const encrypted = encryptForPeer(
        JSON.stringify(payload),
        activeSession.ownSecretKey,
        activeSession.peerPublicKey,
      );
      relayRef.current?.send({
        type: "signal",
        roomId: activeSession.roomId,
        id: makeMessageId(),
        senderPublicKey: activeSession.ownPublicKey,
        ...encrypted,
        sentAt: Date.now(),
      });
    } catch {
      // Interaction signals are optional and never block message delivery.
    }
  }, []);

  const handlePacket = useCallback(
    async (packet: RelayPacket) => {
      const activeSession = sessionRef.current;
      if (!activeSession || packet.roomId !== activeSession.roomId) return;

      if (packet.type === "handshake") {
        if (packet.publicKey === activeSession.ownPublicKey) return;
        if (activeSession.peerPublicKey && activeSession.peerPublicKey !== packet.publicKey) {
          setError("تم رصد تغيير في مفتاح الطرف الآخر. أنشئ جلسة جديدة للتحقق.");
          return;
        }
        if (!activeSession.peerPublicKey) {
          await updateSession({ ...activeSession, peerPublicKey: packet.publicKey, verified: false });
        }
        return;
      }

      if (!activeSession.peerPublicKey || packet.senderPublicKey !== activeSession.peerPublicKey) return;

      if (packet.type === "signal") {
        try {
          const signal = JSON.parse(
            decryptFromPeer(packet, activeSession.ownSecretKey, activeSession.peerPublicKey),
          ) as SignalPayload;
          if (signal.kind === "typing") {
            setPeerIsTyping(signal.active);
            if (peerTypingTimeoutRef.current) clearTimeout(peerTypingTimeoutRef.current);
            if (signal.active) {
              peerTypingTimeoutRef.current = setTimeout(() => setPeerIsTyping(false), 2600);
            }
          }
          if (signal.kind === "call-invite") {
            setIncomingCall({ callId: signal.callId, roomId: signal.roomId, sentAt: signal.sentAt });
          }
          if (signal.kind === "call-cancel") {
            setIncomingCall((current) => (current?.callId === signal.callId ? null : current));
          }
          if (signal.kind === "delivered" || signal.kind === "read") {
            const statusRank = { sent: 0, delivered: 1, read: 2 } as const;
            const nextMessages = messagesRef.current.map((message) =>
              message.id === signal.messageId &&
              message.direction === "outgoing" &&
              statusRank[message.status as keyof typeof statusRank] < statusRank[signal.kind]
                ? { ...message, status: signal.kind }
                : message,
            );
            if (nextMessages.some((message, index) => message !== messagesRef.current[index])) {
              await persistMessages(nextMessages);
            }
          }
        } catch {
          setError("وصلت إشارة لم تجتز التحقق التشفيري، وتم تجاهلها.");
        }
        return;
      }

      if (messagesRef.current.some((message) => message.id === packet.id)) {
        sendEncryptedSignal({ kind: "delivered", messageId: packet.id });
        return;
      }
      try {
        const text = decryptFromPeer(packet, activeSession.ownSecretKey, activeSession.peerPublicKey);
        await persistMessages([
          ...messagesRef.current,
          { id: packet.id, direction: "incoming", text, sentAt: packet.sentAt, status: "received" },
        ]);
        sendEncryptedSignal({ kind: "delivered", messageId: packet.id });
      } catch {
        setError("وصلت حزمة لم تجتز التحقق التشفيري، ولم تُعرض.");
      }
    },
    [persistMessages, sendEncryptedSignal, updateSession],
  );

  const openRelay = useCallback(
    (activeSession: ChatSession) => {
      relayRef.current?.close();
      const relay = new RelayClient(getApiBaseUrl(), activeSession.roomId, {
        onState: setConnection,
        onError: setError,
        onPacket: (packet) => void handlePacket(packet),
      });
      relayRef.current = relay;
      relay.connect();
      const handshakeTimer = setTimeout(() => {
        try {
          relay.send({ type: "handshake", roomId: activeSession.roomId, publicKey: activeSession.ownPublicKey });
        } catch {
          // The socket event will expose a connection error if the channel did not open.
        }
      }, 450);
      return () => clearTimeout(handshakeTimer);
    },
    [handlePacket],
  );

  useEffect(() => {
    let mounted = true;
    void (async () => {
      const storedSession = await loadSession();
      if (!mounted) return;
      if (storedSession) {
        sessionRef.current = storedSession;
        setSession(storedSession);
        const storedMessages = await loadMessages(storedSession.storageKey);
        if (!mounted) return;
        messagesRef.current = storedMessages;
        setMessages(storedMessages);
        openRelay(storedSession);
      }
      setReady(true);
    })();
    return () => {
      mounted = false;
      relayRef.current?.close();
    };
  }, [openRelay]);

  const createSession = useCallback(async () => {
    const identity = createIdentity();
    const roomId = createRoomId();
    const nextSession: ChatSession = {
      version: 1,
      roomId,
      ownPublicKey: identity.publicKey,
      ownSecretKey: identity.secretKey,
      storageKey: createStorageKey(),
      invite: encodeInvite({ v: 1, r: roomId, k: identity.publicKey }),
      verified: false,
      createdAt: Date.now(),
    };
    await updateSession(nextSession);
    await persistMessages([]);
    setError(null);
    openRelay(nextSession);
  }, [openRelay, persistMessages, updateSession]);

  const joinSession = useCallback(
    async (invite: string) => {
      const decoded = decodeInvite(invite);
      const identity = createIdentity();
      const nextSession: ChatSession = {
        version: 1,
        roomId: decoded.r,
        ownPublicKey: identity.publicKey,
        ownSecretKey: identity.secretKey,
        peerPublicKey: decoded.k,
        storageKey: createStorageKey(),
        invite: encodeInvite({ v: 1, r: decoded.r, k: identity.publicKey }),
        verified: false,
        createdAt: Date.now(),
      };
      await updateSession(nextSession);
      await persistMessages([]);
      setError(null);
      openRelay(nextSession);
    },
    [openRelay, persistMessages, updateSession],
  );

  const sendMessage = useCallback(
    async (text: string) => {
      const activeSession = sessionRef.current;
      const cleanText = text.trim();
      if (!activeSession?.peerPublicKey) throw new Error("انتظر اتصال الطرف الآخر أولًا.");
      if (!cleanText) return;
      const encrypted = encryptForPeer(cleanText, activeSession.ownSecretKey, activeSession.peerPublicKey);
      const packet = {
        type: "message" as const,
        roomId: activeSession.roomId,
        id: makeMessageId(),
        senderPublicKey: activeSession.ownPublicKey,
        ...encrypted,
        sentAt: Date.now(),
      };
      relayRef.current?.send(packet);
      await persistMessages([
        ...messagesRef.current,
        { id: packet.id, direction: "outgoing", text: cleanText, sentAt: packet.sentAt, status: "sent" },
      ]);
    },
    [persistMessages],
  );

  const retryMessage = useCallback(async (messageId: string) => {
    const activeSession = sessionRef.current;
    const message = messagesRef.current.find(
      (item) => item.id === messageId && item.direction === "outgoing" && item.status === "sent",
    );
    if (!activeSession?.peerPublicKey || !message) {
      throw new Error("لا يمكن إعادة إرسال هذه الرسالة.");
    }
    const encrypted = encryptForPeer(message.text, activeSession.ownSecretKey, activeSession.peerPublicKey);
    relayRef.current?.send({
      type: "message",
      roomId: activeSession.roomId,
      id: message.id,
      senderPublicKey: activeSession.ownPublicKey,
      ...encrypted,
      sentAt: message.sentAt,
    });
  }, []);

  const deletePendingMessage = useCallback(async (messageId: string) => {
    const nextMessages = removePendingOutgoingMessage(messagesRef.current, messageId);
    if (nextMessages === messagesRef.current) {
      throw new Error("لا يمكن حذف رسالة تم تأكيد تسليمها أو قراءتها.");
    }
    await persistMessages(nextMessages);
  }, [persistMessages]);

  const setTyping = useCallback((isTyping: boolean) => {
    const activeSession = sessionRef.current;
    const now = Date.now();
    const canRefreshTyping = isTyping && now - lastTypingSignalAtRef.current > 900;
    if (!activeSession?.peerPublicKey || (typingStateRef.current === isTyping && !canRefreshTyping)) return;
    typingStateRef.current = isTyping;
    lastTypingSignalAtRef.current = now;
    sendEncryptedSignal({ kind: "typing", active: isTyping });
  }, [sendEncryptedSignal]);

  const markIncomingMessagesRead = useCallback(async () => {
    const unreadIncoming = messagesRef.current.filter(
      (message) => message.direction === "incoming" && !message.readAt,
    );
    if (!unreadIncoming.length) return;
    const readAt = Date.now();
    await persistMessages(
      messagesRef.current.map((message) =>
        message.direction === "incoming" && !message.readAt ? { ...message, readAt } : message,
      ),
    );
    unreadIncoming.forEach((message) => sendEncryptedSignal({ kind: "read", messageId: message.id }));
  }, [persistMessages, sendEncryptedSignal]);

  const makeCallDetails = useCallback((callId: string): CallJoinDetails => {
    const activeSession = sessionRef.current;
    if (!activeSession?.peerPublicKey) throw new Error("انتظر اتصال الطرف الآخر قبل بدء مكالمة.");
    return {
      roomId: activeSession.roomId,
      participantId: activeSession.ownPublicKey.replace(/[^A-Za-z0-9_-]/g, "").slice(0, 60),
      encryptionKey: deriveCallEncryptionKey(activeSession.ownSecretKey, activeSession.peerPublicKey),
      callId,
    };
  }, []);

  const beginCall = useCallback(() => {
    if (connection !== "connected") throw new Error("لا يمكن بدء المكالمة قبل عودة الاتصال.");
    const callId = createRoomId();
    const details = makeCallDetails(callId);
    sendEncryptedSignal({ kind: "call-invite", callId, roomId: details.roomId, sentAt: Date.now() });
    return details;
  }, [connection, makeCallDetails, sendEncryptedSignal]);

  const acceptIncomingCall = useCallback(() => {
    if (!incomingCall) throw new Error("لا توجد دعوة مكالمة نشطة.");
    const details = makeCallDetails(incomingCall.callId);
    setIncomingCall(null);
    return details;
  }, [incomingCall, makeCallDetails]);

  const dismissIncomingCall = useCallback(() => setIncomingCall(null), []);

  const endCall = useCallback((callId: string) => {
    setIncomingCall((current) => (current?.callId === callId ? null : current));
    sendEncryptedSignal({ kind: "call-cancel", callId });
  }, [sendEncryptedSignal]);

  const confirmSafetyNumber = useCallback(async () => {
    const activeSession = sessionRef.current;
    if (!activeSession?.peerPublicKey) return;
    await updateSession({ ...activeSession, verified: true });
  }, [updateSession]);

  const clearSession = useCallback(async () => {
    relayRef.current?.close();
    relayRef.current = null;
    if (peerTypingTimeoutRef.current) clearTimeout(peerTypingTimeoutRef.current);
    typingStateRef.current = false;
    lastTypingSignalAtRef.current = 0;
    setPeerIsTyping(false);
    setIncomingCall(null);
    sessionRef.current = null;
    messagesRef.current = [];
    setSession(null);
    setMessages([]);
    setConnection("disconnected");
    setError(null);
    await clearLocalChat();
  }, []);

  const value = useMemo<ChatContextValue>(
    () => ({
      ready,
      session,
      messages,
      connection,
      peerIsTyping,
      incomingCall,
      error,
      safetyNumber: session?.peerPublicKey ? makeSafetyNumber(session.ownPublicKey, session.peerPublicKey) : null,
      createSession,
      joinSession,
      sendMessage,
      retryMessage,
      deletePendingMessage,
      setTyping,
      markIncomingMessagesRead,
      beginCall,
      acceptIncomingCall,
      dismissIncomingCall,
      endCall,
      confirmSafetyNumber,
      clearSession,
      dismissError: () => setError(null),
    }),
    [acceptIncomingCall, beginCall, clearSession, confirmSafetyNumber, connection, createSession, deletePendingMessage, dismissIncomingCall, endCall, error, incomingCall, joinSession, markIncomingMessagesRead, messages, peerIsTyping, ready, retryMessage, sendMessage, session, setTyping],
  );

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export function useChat() {
  const value = useContext(ChatContext);
  if (!value) throw new Error("useChat must be used inside ChatProvider");
  return value;
}
