import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

import { decryptLocalValue, encryptLocalValue, type CipherEnvelope } from "./crypto";
import type { ChatMessage, ChatSession } from "./types";

const SESSION_KEY = "hamas.session.v1";
const MESSAGE_VAULT_KEY = "hamas.messages.v1";
const MAX_STORED_MESSAGES = 300;

function getWebStorage() {
  if (typeof window === "undefined") return null;
  return window.sessionStorage;
}

async function saveSensitiveValue(key: string, value: string) {
  if (Platform.OS === "web") {
    getWebStorage()?.setItem(key, value);
    return;
  }
  await SecureStore.setItemAsync(key, value, {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  });
}

async function getSensitiveValue(key: string) {
  if (Platform.OS === "web") return getWebStorage()?.getItem(key) ?? null;
  return SecureStore.getItemAsync(key, {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  });
}

async function removeSensitiveValue(key: string) {
  if (Platform.OS === "web") {
    getWebStorage()?.removeItem(key);
    return;
  }
  await SecureStore.deleteItemAsync(key, {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  });
}

export async function saveSession(session: ChatSession) {
  await saveSensitiveValue(SESSION_KEY, JSON.stringify(session));
}

export async function loadSession(): Promise<ChatSession | null> {
  const encoded = await getSensitiveValue(SESSION_KEY);
  if (!encoded) return null;
  try {
    return JSON.parse(encoded) as ChatSession;
  } catch {
    await removeSensitiveValue(SESSION_KEY);
    return null;
  }
}

export async function saveMessages(messages: ChatMessage[], storageKey: string) {
  const vault = encryptLocalValue(messages.slice(-MAX_STORED_MESSAGES), storageKey);
  await AsyncStorage.setItem(MESSAGE_VAULT_KEY, JSON.stringify(vault));
}

export async function loadMessages(storageKey: string): Promise<ChatMessage[]> {
  const encoded = await AsyncStorage.getItem(MESSAGE_VAULT_KEY);
  if (!encoded) return [];
  try {
    return decryptLocalValue<ChatMessage[]>(JSON.parse(encoded) as CipherEnvelope, storageKey);
  } catch {
    await AsyncStorage.removeItem(MESSAGE_VAULT_KEY);
    return [];
  }
}

export async function clearLocalChat() {
  await Promise.all([removeSensitiveValue(SESSION_KEY), AsyncStorage.removeItem(MESSAGE_VAULT_KEY)]);
}
