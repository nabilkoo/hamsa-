import "react-native-get-random-values";
import nacl from "tweetnacl";
import * as naclUtil from "tweetnacl-util";

export type LocalIdentity = {
  publicKey: string;
  secretKey: string;
};

export type CipherEnvelope = {
  nonce: string;
  ciphertext: string;
};

const decode = (value: string) => naclUtil.decodeBase64(value);
const encode = (value: Uint8Array) => naclUtil.encodeBase64(value);

function mergeBytes(...values: Uint8Array[]) {
  const length = values.reduce((total, value) => total + value.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  values.forEach((value) => {
    output.set(value, offset);
    offset += value.length;
  });
  return output;
}

export function createIdentity(): LocalIdentity {
  const pair = nacl.box.keyPair();
  return { publicKey: encode(pair.publicKey), secretKey: encode(pair.secretKey) };
}

export function createRoomId() {
  return encode(nacl.randomBytes(18)).replace(/[+/=]/g, "").slice(0, 22);
}

export function createStorageKey() {
  return encode(nacl.randomBytes(nacl.secretbox.keyLength));
}

export function makeSafetyNumber(firstPublicKey: string, secondPublicKey: string) {
  const [first, second] = [firstPublicKey, secondPublicKey].sort();
  const digest = nacl.hash(mergeBytes(decode(first), decode(second)));
  const digits = Array.from(digest.slice(0, 12))
    .map((byte) => byte.toString().padStart(3, "0"))
    .join("")
    .slice(0, 30);
  return digits.match(/.{1,5}/g)?.join(" ") ?? digits;
}

/** Derives a media-encryption key locally; the LiveKit service never receives it. */
export function deriveCallEncryptionKey(ownSecretKey: string, peerPublicKey: string) {
  const sharedKey = nacl.box.before(decode(peerPublicKey), decode(ownSecretKey));
  return encode(nacl.hash(sharedKey).slice(0, 32));
}

export function encryptForPeer(
  plaintext: string,
  ownSecretKey: string,
  peerPublicKey: string,
): CipherEnvelope {
  const nonce = nacl.randomBytes(nacl.box.nonceLength);
  const sharedKey = nacl.box.before(decode(peerPublicKey), decode(ownSecretKey));
  const ciphertext = nacl.box.after(naclUtil.decodeUTF8(plaintext), nonce, sharedKey);
  return { nonce: encode(nonce), ciphertext: encode(ciphertext) };
}

export function decryptFromPeer(
  envelope: CipherEnvelope,
  ownSecretKey: string,
  peerPublicKey: string,
) {
  const sharedKey = nacl.box.before(decode(peerPublicKey), decode(ownSecretKey));
  const plaintext = nacl.box.open.after(decode(envelope.ciphertext), decode(envelope.nonce), sharedKey);
  if (!plaintext) throw new Error("تعذر التحقق من سلامة الرسالة المشفرة.");
  return naclUtil.encodeUTF8(plaintext);
}

export function encryptLocalValue(value: unknown, storageKey: string): CipherEnvelope {
  const nonce = nacl.randomBytes(nacl.secretbox.nonceLength);
  const content = naclUtil.decodeUTF8(JSON.stringify(value));
  const ciphertext = nacl.secretbox(content, nonce, decode(storageKey));
  return { nonce: encode(nonce), ciphertext: encode(ciphertext) };
}

export function decryptLocalValue<T>(envelope: CipherEnvelope, storageKey: string): T {
  const plaintext = nacl.secretbox.open(decode(envelope.ciphertext), decode(envelope.nonce), decode(storageKey));
  if (!plaintext) throw new Error("تعذر فتح البيانات المحلية المشفرة.");
  return JSON.parse(naclUtil.encodeUTF8(plaintext)) as T;
}
