import type { ConnectionState, RelayPacket } from "./types";

type RelayCallbacks = {
  onState: (state: ConnectionState) => void;
  onPacket: (packet: RelayPacket) => void;
  onError: (message: string) => void;
};

function asWebSocketUrl(apiBaseUrl: string) {
  return `${apiBaseUrl.replace(/^http/, "ws").replace(/\/$/, "")}/api/relay`;
}

function parseEventData(data: unknown) {
  if (typeof data !== "string") return null;
  try {
    return JSON.parse(data) as RelayPacket | { type: "status"; peers: number } | { type: "error"; message: string };
  } catch {
    return null;
  }
}

export class RelayClient {
  private socket: WebSocket | null = null;

  constructor(
    private readonly apiBaseUrl: string,
    private readonly roomId: string,
    private readonly callbacks: RelayCallbacks,
  ) {}

  connect() {
    this.callbacks.onState("connecting");
    const socket = new WebSocket(asWebSocketUrl(this.apiBaseUrl));
    this.socket = socket;

    socket.onopen = () => {
      this.callbacks.onState("connected");
      socket.send(JSON.stringify({ type: "hello", roomId: this.roomId }));
    };
    socket.onclose = () => this.callbacks.onState("disconnected");
    socket.onerror = () => this.callbacks.onError("تعذر الاتصال بقناة الترحيل الآن.");
    socket.onmessage = (event) => {
      const message = parseEventData(event.data);
      if (!message) return;
      if (message.type === "error") {
        this.callbacks.onError(message.message);
        return;
      }
      if (message.type !== "status") this.callbacks.onPacket(message);
    };
  }

  send(packet: RelayPacket) {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
      throw new Error("قناة الاتصال غير جاهزة.");
    }
    this.socket.send(JSON.stringify(packet));
  }

  close() {
    this.socket?.close();
    this.socket = null;
  }
}
