import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

import type { PinCredential } from "./pin";

const APP_LOCK_KEY = "hamas.app-lock.v1";

export type AppLockConfig = {
  credential: PinCredential;
  biometricEnabled: boolean;
  createdAt: number;
};

function webStorage() {
  if (typeof window === "undefined") return null;
  return window.sessionStorage;
}

export async function loadAppLockConfig(): Promise<AppLockConfig | null> {
  const raw =
    Platform.OS === "web"
      ? webStorage()?.getItem(APP_LOCK_KEY) ?? null
      : await SecureStore.getItemAsync(APP_LOCK_KEY, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AppLockConfig;
  } catch {
    return null;
  }
}

export async function saveAppLockConfig(config: AppLockConfig) {
  const raw = JSON.stringify(config);
  if (Platform.OS === "web") {
    webStorage()?.setItem(APP_LOCK_KEY, raw);
    return;
  }
  await SecureStore.setItemAsync(APP_LOCK_KEY, raw, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}

export async function clearAppLockConfig() {
  if (Platform.OS === "web") {
    webStorage()?.removeItem(APP_LOCK_KEY);
    return;
  }
  await SecureStore.deleteItemAsync(APP_LOCK_KEY, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}
