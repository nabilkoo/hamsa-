import "react-native-get-random-values";
import nacl from "tweetnacl";
import * as naclUtil from "tweetnacl-util";

export type PinCredential = {
  salt: string;
  digest: string;
};

const MIN_PIN_LENGTH = 4;
const MAX_PIN_LENGTH = 8;

export function isValidPin(pin: string) {
  return new RegExp(`^\\d{${MIN_PIN_LENGTH},${MAX_PIN_LENGTH}}$`).test(pin);
}

function digestPin(pin: string, salt: Uint8Array) {
  const pinBytes = naclUtil.decodeUTF8(pin);
  const content = new Uint8Array(salt.length + pinBytes.length);
  content.set(salt);
  content.set(pinBytes, salt.length);
  return naclUtil.encodeBase64(nacl.hash(content));
}

export function createPinCredential(pin: string): PinCredential {
  if (!isValidPin(pin)) throw new Error("استخدم رمزًا من 4 إلى 8 أرقام.");
  const salt = nacl.randomBytes(16);
  return { salt: naclUtil.encodeBase64(salt), digest: digestPin(pin, salt) };
}

export function verifyPin(pin: string, credential: PinCredential) {
  if (!isValidPin(pin)) return false;
  const expected = naclUtil.decodeBase64(credential.digest);
  const actual = naclUtil.decodeBase64(digestPin(pin, naclUtil.decodeBase64(credential.salt)));
  return nacl.verify(expected, actual);
}
