import * as LocalAuthentication from "expo-local-authentication";
import { AppState, Platform } from "react-native";
import { createContext, type PropsWithChildren, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { createPinCredential, verifyPin } from "./pin";
import { clearAppLockConfig, loadAppLockConfig, saveAppLockConfig, type AppLockConfig } from "./storage";

type AppLockContextValue = {
  ready: boolean;
  config: AppLockConfig | null;
  isLocked: boolean;
  biometricAvailable: boolean;
  setupLock: (pin: string, biometricEnabled: boolean) => Promise<void>;
  unlockWithPin: (pin: string) => boolean;
  unlockWithBiometrics: () => Promise<boolean>;
  updateBiometricPreference: (enabled: boolean) => Promise<void>;
  disableLock: () => Promise<void>;
  lockNow: () => void;
};

const AppLockContext = createContext<AppLockContextValue | null>(null);

async function checkBiometricAvailability() {
  if (Platform.OS === "web") return false;
  const [hasHardware, isEnrolled] = await Promise.all([
    LocalAuthentication.hasHardwareAsync(),
    LocalAuthentication.isEnrolledAsync(),
  ]);
  return hasHardware && isEnrolled;
}

export function AppLockProvider({ children }: PropsWithChildren) {
  const [ready, setReady] = useState(false);
  const [config, setConfig] = useState<AppLockConfig | null>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [biometricAvailable, setBiometricAvailable] = useState(false);

  useEffect(() => {
    let mounted = true;
    void (async () => {
      const [storedConfig, canUseBiometrics] = await Promise.all([loadAppLockConfig(), checkBiometricAvailability()]);
      if (!mounted) return;
      setConfig(storedConfig);
      setBiometricAvailable(canUseBiometrics);
      setIsLocked(Boolean(storedConfig));
      setReady(true);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "background" || state === "inactive") setIsLocked((currentlyLocked) => Boolean(config) || currentlyLocked);
    });
    return () => subscription.remove();
  }, [config]);

  const setupLock = useCallback(async (pin: string, biometricEnabled: boolean) => {
    const nextConfig: AppLockConfig = {
      credential: createPinCredential(pin),
      biometricEnabled: biometricEnabled && (await checkBiometricAvailability()),
      createdAt: Date.now(),
    };
    await saveAppLockConfig(nextConfig);
    setConfig(nextConfig);
    setIsLocked(false);
  }, []);

  const unlockWithPin = useCallback(
    (pin: string) => {
      if (!config || !verifyPin(pin, config.credential)) return false;
      setIsLocked(false);
      return true;
    },
    [config],
  );

  const unlockWithBiometrics = useCallback(async () => {
    if (!config?.biometricEnabled || !(await checkBiometricAvailability())) return false;
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: "افتح همس",
      promptDescription: "تحقق من هويتك للوصول إلى المحادثة الخاصة.",
      cancelLabel: "استخدام الرمز",
      disableDeviceFallback: true,
      biometricsSecurityLevel: "weak",
    });
    if (result.success) setIsLocked(false);
    return result.success;
  }, [config]);

  const updateBiometricPreference = useCallback(
    async (enabled: boolean) => {
      if (!config) return;
      const nextConfig = { ...config, biometricEnabled: enabled && (await checkBiometricAvailability()) };
      await saveAppLockConfig(nextConfig);
      setConfig(nextConfig);
      setBiometricAvailable(await checkBiometricAvailability());
    },
    [config],
  );

  const disableLock = useCallback(async () => {
    await clearAppLockConfig();
    setConfig(null);
    setIsLocked(false);
  }, []);

  const value = useMemo<AppLockContextValue>(
    () => ({
      ready,
      config,
      isLocked,
      biometricAvailable,
      setupLock,
      unlockWithPin,
      unlockWithBiometrics,
      updateBiometricPreference,
      disableLock,
      lockNow: () => setIsLocked(true),
    }),
    [biometricAvailable, config, disableLock, isLocked, ready, setupLock, unlockWithBiometrics, unlockWithPin, updateBiometricPreference],
  );

  return <AppLockContext.Provider value={value}>{children}</AppLockContext.Provider>;
}

export function useAppLock() {
  const value = useContext(AppLockContext);
  if (!value) throw new Error("useAppLock must be used inside AppLockProvider");
  return value;
}
