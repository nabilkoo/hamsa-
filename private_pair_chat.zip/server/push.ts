import type { PushToken } from "../drizzle/schema";
import { getFirebaseAccessToken } from "./firebase";

export function createIncomingCallMessage(token: string) {
  return {
    message: {
      token,
      notification: { title: "همس", body: "لديك مكالمة واردة" },
      android: {
        priority: "high",
        notification: { channel_id: "private-calls", sound: "default" },
      },
      data: { kind: "incoming-call" },
    },
  };
}

/** Sends a generic incoming-call alert; no message content or encryption data is sent. */
export async function sendIncomingCallPush(tokens: PushToken[]) {
  if (!tokens.length) return { sent: 0, failed: 0 };
  const { accessToken, projectId } = await getFirebaseAccessToken();
  const url = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;
  const results = await Promise.all(
    tokens.map(async ({ token }) => {
      const response = await fetch(url, {
        method: "POST",
        headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify(createIncomingCallMessage(token)),
      });
      return response.ok;
    }),
  );
  return { sent: results.filter(Boolean).length, failed: results.filter((result) => !result).length };
}
