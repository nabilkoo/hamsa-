import { importPKCS8, SignJWT } from "jose";

export type FirebaseServiceAccount = {
  project_id: string;
  client_email: string;
  private_key: string;
  token_uri?: string;
};

export function getFirebaseServiceAccount(): FirebaseServiceAccount {
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("لم يُضف اعتماد Firebase إلى الخادم بعد.");
  let account: FirebaseServiceAccount;
  try {
    account = JSON.parse(raw) as FirebaseServiceAccount;
  } catch {
    throw new Error("اعتماد Firebase ليس ملف JSON صالحًا.");
  }
  if (!account.project_id || !account.client_email || !account.private_key) {
    throw new Error("اعتماد Firebase يفتقد الحقول الأساسية.");
  }
  return account;
}

/** Obtains an OAuth access token without exposing the service-account key to the client. */
export async function getFirebaseAccessToken() {
  const account = getFirebaseServiceAccount();
  const now = Math.floor(Date.now() / 1000);
  const privateKey = await importPKCS8(account.private_key, "RS256");
  const assertion = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(account.client_email)
    .setSubject(account.client_email)
    .setAudience(account.token_uri ?? "https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 300)
    .sign(privateKey);
  const response = await fetch(account.token_uri ?? "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });
  if (!response.ok) throw new Error(`تعذر التحقق من اعتماد Firebase (${response.status}).`);
  const payload = (await response.json()) as { access_token?: string; expires_in?: number };
  if (!payload.access_token) throw new Error("لم تُرجع Firebase رمز وصول صالحًا.");
  return { accessToken: payload.access_token, expiresIn: payload.expires_in ?? 0, projectId: account.project_id };
}
