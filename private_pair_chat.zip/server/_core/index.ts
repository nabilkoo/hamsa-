import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { WebSocket, WebSocketServer } from "ws";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";

type RelaySocket = WebSocket & { roomId?: string };

function registerEphemeralRelay(server: ReturnType<typeof createServer>) {
  const relay = new WebSocketServer({ noServer: true, maxPayload: 48 * 1024, perMessageDeflate: false });
  const rooms = new Map<string, Set<RelaySocket>>();

  const leaveRoom = (socket: RelaySocket) => {
    const roomId = socket.roomId;
    if (!roomId) return;
    const peers = rooms.get(roomId);
    peers?.delete(socket);
    if (!peers?.size) rooms.delete(roomId);
    socket.roomId = undefined;
  };

  relay.on("connection", (socket: RelaySocket) => {
    socket.on("message", (raw, isBinary) => {
      const rawText = raw.toString();
      if (isBinary || Buffer.byteLength(rawText) > 48 * 1024) return socket.close(1009, "Unsupported payload");
      let packet: unknown;
      try {
        packet = JSON.parse(rawText);
      } catch {
        return socket.close(1003, "Invalid packet");
      }
      if (!packet || typeof packet !== "object") return socket.close(1003, "Invalid packet");
      const data = packet as { type?: string; roomId?: string };

      if (data.type === "hello") {
        if (socket.roomId || !data.roomId || !/^[A-Za-z0-9_-]{16,64}$/.test(data.roomId)) {
          return socket.close(1008, "Invalid room");
        }
        const peers = rooms.get(data.roomId) ?? new Set<RelaySocket>();
        if (peers.size >= 2) {
          socket.send(JSON.stringify({ type: "error", message: "هذه الجلسة ممتلئة بالفعل." }));
          return socket.close(1008, "Room full");
        }
        peers.add(socket);
        rooms.set(data.roomId, peers);
        socket.roomId = data.roomId;
        socket.send(JSON.stringify({ type: "status", peers: peers.size }));
        return;
      }

      if (!socket.roomId || data.roomId !== socket.roomId || (data.type !== "handshake" && data.type !== "message" && data.type !== "signal")) {
        return socket.close(1008, "Invalid route");
      }
      rooms.get(socket.roomId)?.forEach((peer) => {
        if (peer !== socket && peer.readyState === WebSocket.OPEN) peer.send(rawText);
      });
    });
    socket.on("close", () => leaveRoom(socket));
    socket.on("error", () => leaveRoom(socket));
  });

  server.on("upgrade", (request, socket, head) => {
    const pathname = new URL(request.url ?? "/", "http://localhost").pathname;
    if (pathname !== "/api/relay") return;
    relay.handleUpgrade(request, socket, head, (webSocket) => relay.emit("connection", webSocket, request));
  });
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  registerEphemeralRelay(server);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
  });
}

startServer().catch(console.error);
