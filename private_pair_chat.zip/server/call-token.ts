import { AccessToken } from "livekit-server-sdk";

const ROOM_ID_PATTERN = /^[A-Za-z0-9_-]{16,64}$/;
const PARTICIPANT_ID_PATTERN = /^[A-Za-z0-9_-]{16,128}$/;

export type CallTokenInput = {
  roomId: string;
  callId: string;
  participantId: string;
};

function requireLiveKitConfig() {
  const serverUrl = process.env.LIVEKIT_URL;
  const apiKey = process.env.LIVEKIT_API_KEY;
  const apiSecret = process.env.LIVEKIT_API_SECRET;
  if (!serverUrl?.startsWith("wss://") || !apiKey || !apiSecret) {
    throw new Error("إعداد LiveKit غير مكتمل في الخادم.");
  }
  return { serverUrl, apiKey, apiSecret };
}

/**
 * The random chat room identifier acts as an unguessable capability for this
 * two-person prototype. The API secret never leaves this server.
 */
export async function createCallToken({ roomId, callId, participantId }: CallTokenInput) {
  if (!ROOM_ID_PATTERN.test(roomId) || !ROOM_ID_PATTERN.test(callId) || !PARTICIPANT_ID_PATTERN.test(participantId)) {
    throw new Error("بيانات المكالمة غير صالحة.");
  }
  const { serverUrl, apiKey, apiSecret } = requireLiveKitConfig();
  const roomName = `hamas-${roomId}-${callId}`;
  const token = new AccessToken(apiKey, apiSecret, {
    identity: `h-${participantId.slice(0, 28)}`,
    ttl: "10m",
  });
  token.addGrant({
    roomJoin: true,
    room: roomName,
    canPublish: true,
    canSubscribe: true,
    canPublishData: true,
  });
  return {
    serverUrl,
    roomName,
    token: await token.toJwt(),
    expiresAt: Date.now() + 10 * 60 * 1000,
  };
}
