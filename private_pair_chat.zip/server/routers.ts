import { COOKIE_NAME } from "../shared/const.js";
import { z } from "zod";
import { createCallToken } from "./call-token";
import * as db from "./db";
import { sendIncomingCallPush } from "./push";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const fcmToken = z.string().min(20).max(4096).regex(/^[A-Za-z0-9:_-]+$/);

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  calls: router({
    createToken: publicProcedure
      .input(
        z.object({
          roomId: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
          callId: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
          participantId: z.string().regex(/^[A-Za-z0-9_-]{16,128}$/),
        }),
      )
      .mutation(({ input }) => createCallToken(input)),
    registerPushToken: publicProcedure
      .input(
        z.object({
          roomId: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
          token: fcmToken,
        }),
      )
      .mutation(async ({ input }) => {
        await db.registerPushToken(input.roomId, input.token);
        return { registered: true };
      }),
    removePushToken: publicProcedure
      .input(
        z.object({
          roomId: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
          token: fcmToken,
        }),
      )
      .mutation(async ({ input }) => {
        await db.removePushToken(input.roomId, input.token);
        return { removed: true };
      }),
    notifyIncomingCall: publicProcedure
      .input(
        z.object({
          roomId: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
          excludeToken: fcmToken.optional(),
        }),
      )
      .mutation(async ({ input }) => sendIncomingCallPush(await db.getPushTokensForRoom(input.roomId, input.excludeToken))),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
