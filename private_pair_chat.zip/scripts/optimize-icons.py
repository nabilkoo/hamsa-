from pathlib import Path

from PIL import Image

root = Path(__file__).resolve().parents[1] / "assets" / "images"
names = ["icon.png", "splash-icon.png", "favicon.png", "android-icon-foreground.png"]

for name in names:
    path = root / name
    with Image.open(path) as source:
        image = source.convert("RGB")
        image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
        optimized = image.quantize(colors=256, method=Image.Quantize.MEDIANCUT)
        optimized.save(path, format="PNG", optimize=True, compress_level=9)
        print(f"{name}: {path.stat().st_size} bytes")
