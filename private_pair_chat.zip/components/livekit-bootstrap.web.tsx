import { type PropsWithChildren } from "react";

export function LiveKitBootstrap({ children }: PropsWithChildren) {
  return <>{children}</>;
}
