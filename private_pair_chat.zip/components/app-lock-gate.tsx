import { useAppLock } from "@/lib/app-lock/app-lock-provider";
import { useState, type PropsWithChildren } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

export function AppLockGate({ children }: PropsWithChildren) {
  const { ready, config, isLocked, biometricAvailable, unlockWithPin, unlockWithBiometrics } = useAppLock();
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [checkingBiometric, setCheckingBiometric] = useState(false);

  const unlock = () => {
    if (!unlockWithPin(pin)) {
      setPin("");
      setError("الرمز غير صحيح. حاول مرة أخرى.");
      return;
    }
    setError("");
    setPin("");
  };

  const biometricUnlock = async () => {
    setCheckingBiometric(true);
    const success = await unlockWithBiometrics();
    setCheckingBiometric(false);
    if (!success) setError("تعذر التحقق البيومتري. استخدم رمز القفل.");
  };

  if (!ready) {
    return <View style={styles.loading}><ActivityIndicator color="#29B6D8" /></View>;
  }
  if (!isLocked || !config) return <>{children}</>;

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={styles.lockIcon}><Text style={styles.lockSymbol}>▣</Text></View>
      <Text style={styles.title}>همس مقفل</Text>
      <Text style={styles.subtitle}>أدخل رمز القفل للوصول إلى محادثتك الخاصة.</Text>
      <TextInput
        value={pin}
        onChangeText={(value) => {
          setError("");
          setPin(value.replace(/\D/g, "").slice(0, 8));
        }}
        onSubmitEditing={unlock}
        autoFocus
        keyboardType="number-pad"
        secureTextEntry
        maxLength={8}
        placeholder="رمز القفل"
        placeholderTextColor="#7890A3"
        style={styles.pinInput}
        textAlign="center"
        accessibilityLabel="رمز قفل التطبيق"
      />
      {error ? <Text style={styles.error}>{error}</Text> : <Text style={styles.hint}>رمز من 4 إلى 8 أرقام</Text>}
      <Pressable onPress={unlock} style={({ pressed }) => [styles.unlockButton, pressed && styles.pressed]}>
        <Text style={styles.unlockText}>فتح التطبيق</Text>
      </Pressable>
      {config.biometricEnabled && biometricAvailable && (
        <Pressable disabled={checkingBiometric} onPress={() => void biometricUnlock()} style={({ pressed }) => [styles.biometricButton, (pressed || checkingBiometric) && styles.pressed]}>
          <Text style={styles.biometricText}>{checkingBiometric ? "جارٍ التحقق…" : "استخدام البصمة أو Face ID"}</Text>
        </Pressable>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, backgroundColor: "#0A1420", alignItems: "center", justifyContent: "center" },
  screen: { flex: 1, backgroundColor: "#0A1420", paddingHorizontal: 28, justifyContent: "center", alignItems: "center" },
  lockIcon: { width: 78, height: 78, borderRadius: 25, backgroundColor: "#132537", alignItems: "center", justifyContent: "center", marginBottom: 20 },
  lockSymbol: { color: "#29B6D8", fontSize: 34, lineHeight: 38 },
  title: { color: "#F3F8FC", fontSize: 27, fontWeight: "800" },
  subtitle: { color: "#9FB5C6", fontSize: 15, lineHeight: 23, textAlign: "center", marginTop: 10, maxWidth: 280 },
  pinInput: { width: "100%", color: "#F3F8FC", backgroundColor: "#132537", borderColor: "#234157", borderWidth: 1, borderRadius: 18, fontSize: 23, letterSpacing: 8, paddingVertical: 15, marginTop: 29 },
  hint: { color: "#7890A3", fontSize: 12, marginTop: 10 },
  error: { color: "#FF8E98", fontSize: 12, marginTop: 10, textAlign: "center" },
  unlockButton: { width: "100%", minHeight: 54, backgroundColor: "#29B6D8", borderRadius: 17, justifyContent: "center", alignItems: "center", marginTop: 20 },
  unlockText: { color: "#0A1420", fontSize: 16, fontWeight: "800" },
  biometricButton: { minHeight: 48, justifyContent: "center", alignItems: "center", marginTop: 10 },
  biometricText: { color: "#29B6D8", fontSize: 14, fontWeight: "700" },
  pressed: { opacity: 0.62, transform: [{ scale: 0.98 }] },
});
