import type { CallJoinDetails } from "@/lib/chat/types";
import { Pressable, StyleSheet, Text, View } from "react-native";

export function LiveCall({ onEnd }: { details: CallJoinDetails; onEnd: () => void }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>المكالمات متاحة في تطبيق الجوال</Text>
      <Text style={styles.copy}>تحتاج مكالمات الصوت والصورة إلى بناء Android أو iOS مخصص، ولا تعمل في معاينة الويب.</Text>
      <Pressable onPress={onEnd} style={styles.button}><Text style={styles.buttonText}>العودة للمحادثة</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A1420", padding: 28, justifyContent: "center", alignItems: "center" },
  title: { color: "#F3F8FC", fontSize: 22, fontWeight: "800", textAlign: "center" },
  copy: { color: "#9FB5C6", fontSize: 15, lineHeight: 24, textAlign: "center", marginTop: 12 },
  button: { backgroundColor: "#29B6D8", paddingHorizontal: 20, minHeight: 48, borderRadius: 16, justifyContent: "center", marginTop: 28 },
  buttonText: { color: "#0A1420", fontWeight: "800" },
});
