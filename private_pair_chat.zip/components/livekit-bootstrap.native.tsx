import { registerGlobals } from "@livekit/react-native";
import { type PropsWithChildren, useEffect } from "react";

export function LiveKitBootstrap({ children }: PropsWithChildren) {
  useEffect(() => {
    registerGlobals();
  }, []);
  return <>{children}</>;
}
