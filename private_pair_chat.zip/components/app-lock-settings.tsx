import { useAppLock } from "@/lib/app-lock/app-lock-provider";
import { useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Switch, Text, TextInput, View } from "react-native";

export function AppLockSettings({ onBack }: { onBack: () => void }) {
  const { config, biometricAvailable, setupLock, updateBiometricPreference, disableLock } = useAppLock();
  const [changingPin, setChangingPin] = useState(false);
  const [pin, setPin] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [useBiometric, setUseBiometric] = useState(config?.biometricEnabled ?? biometricAvailable);
  const [error, setError] = useState("");
  const [working, setWorking] = useState(false);

  const normalizePin = (value: string, setter: (value: string) => void) => {
    setError("");
    setter(value.replace(/\D/g, "").slice(0, 8));
  };

  const saveLock = async () => {
    if (pin.length < 4 || pin.length > 8) return setError("استخدم رمزًا من 4 إلى 8 أرقام.");
    if (pin !== confirmation) return setError("الرمزان غير متطابقين.");
    setWorking(true);
    try {
      await setupLock(pin, useBiometric);
      onBack();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : "تعذر حفظ القفل.");
    } finally {
      setWorking(false);
    }
  };

  const disable = () => {
    Alert.alert("إيقاف قفل التطبيق؟", "سيُزال رمز القفل وإعداد الفتح البيومتري من هذا الجهاز.", [
      { text: "إلغاء", style: "cancel" },
      { text: "إيقاف القفل", style: "destructive", onPress: () => void disableLock().then(onBack) },
    ]);
  };

  if (config && !changingPin) {
    return (
      <View style={styles.content}>
        <Text style={styles.title}>قفل التطبيق</Text>
        <Text style={styles.copy}>القفل مفعّل. سيطلب التطبيق رمزك عند فتحه أو عند عودته من الخلفية.</Text>
        <View style={styles.settingCard}>
          <View style={styles.settingCopy}><Text style={styles.settingTitle}>فتح بالبصمة أو Face ID</Text><Text style={styles.settingHint}>{biometricAvailable ? "استخدم التحقق البيومتري بدل إدخال الرمز." : "غير متاح على هذا الجهاز."}</Text></View>
          <Switch value={config.biometricEnabled} disabled={!biometricAvailable} onValueChange={(value) => void updateBiometricPreference(value)} trackColor={{ false: "#234157", true: "#187C96" }} thumbColor="#F3F8FC" />
        </View>
        <Pressable onPress={() => setChangingPin(true)} style={({ pressed }) => [styles.outlineButton, pressed && styles.pressed]}><Text style={styles.outlineText}>تغيير رمز القفل</Text></Pressable>
        <Pressable onPress={disable} style={({ pressed }) => [styles.destructiveButton, pressed && styles.pressed]}><Text style={styles.destructiveText}>إيقاف قفل التطبيق</Text></Pressable>
      </View>
    );
  }

  return (
    <View style={styles.content}>
      <Text style={styles.title}>{changingPin ? "تغيير رمز القفل" : "فعّل قفل التطبيق"}</Text>
      <Text style={styles.copy}>اختر رمزًا رقميًا من 4 إلى 8 أرقام. يُحفظ التحقق منه محليًا فقط.</Text>
      <TextInput value={pin} onChangeText={(value) => normalizePin(value, setPin)} keyboardType="number-pad" secureTextEntry maxLength={8} placeholder="رمز القفل" placeholderTextColor="#7890A3" style={styles.input} textAlign="center" />
      <TextInput value={confirmation} onChangeText={(value) => normalizePin(value, setConfirmation)} keyboardType="number-pad" secureTextEntry maxLength={8} placeholder="أعد كتابة الرمز" placeholderTextColor="#7890A3" style={styles.input} textAlign="center" />
      <View style={styles.settingCard}>
        <View style={styles.settingCopy}><Text style={styles.settingTitle}>فتح بالبصمة أو Face ID</Text><Text style={styles.settingHint}>{biometricAvailable ? "اختياري، مع بقاء الرمز بديلًا دائمًا." : Platform.OS === "web" ? "يتوفر عند تجربة التطبيق على الجوال." : "أضف بصمة أو Face ID إلى الجهاز أولًا."}</Text></View>
        <Switch value={useBiometric} disabled={!biometricAvailable} onValueChange={setUseBiometric} trackColor={{ false: "#234157", true: "#187C96" }} thumbColor="#F3F8FC" />
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <Pressable disabled={working} onPress={() => void saveLock()} style={({ pressed }) => [styles.primaryButton, (pressed || working) && styles.pressed]}><Text style={styles.primaryText}>{working ? "جارٍ الحفظ…" : "حفظ القفل"}</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { flex: 1, paddingHorizontal: 24, paddingTop: 22 },
  title: { color: "#F3F8FC", fontSize: 27, fontWeight: "800", textAlign: "right" },
  copy: { color: "#9FB5C6", fontSize: 15, lineHeight: 24, textAlign: "right", marginTop: 9 },
  input: { color: "#F3F8FC", backgroundColor: "#132537", borderColor: "#234157", borderWidth: 1, borderRadius: 16, paddingVertical: 13, fontSize: 20, letterSpacing: 6, marginTop: 14 },
  settingCard: { marginTop: 20, backgroundColor: "#132537", borderColor: "#234157", borderWidth: 1, borderRadius: 17, padding: 15, flexDirection: "row-reverse", alignItems: "center", gap: 12 },
  settingCopy: { flex: 1, alignItems: "flex-end" },
  settingTitle: { color: "#F3F8FC", fontSize: 14, fontWeight: "800", textAlign: "right" },
  settingHint: { color: "#9FB5C6", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 4 },
  primaryButton: { minHeight: 53, backgroundColor: "#29B6D8", borderRadius: 17, alignItems: "center", justifyContent: "center", marginTop: 18 },
  primaryText: { color: "#0A1420", fontSize: 16, fontWeight: "800" },
  outlineButton: { minHeight: 50, borderColor: "#234157", borderWidth: 1, borderRadius: 16, alignItems: "center", justifyContent: "center", marginTop: 18 },
  outlineText: { color: "#29B6D8", fontSize: 15, fontWeight: "800" },
  destructiveButton: { minHeight: 48, alignItems: "center", justifyContent: "center", marginTop: 9 },
  destructiveText: { color: "#FF8E98", fontSize: 14, fontWeight: "800" },
  error: { color: "#FF8E98", fontSize: 13, textAlign: "right", marginTop: 12 },
  pressed: { opacity: 0.62, transform: [{ scale: 0.98 }] },
});
