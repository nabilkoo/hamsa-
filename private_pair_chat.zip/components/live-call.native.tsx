import type { CallJoinDetails } from "@/lib/chat/types";
import { trpc } from "@/lib/trpc";
import { AudioSession, isTrackReference, LiveKitRoom, registerGlobals, useLocalParticipant, useRNE2EEManager, useRoomContext, useTracks, VideoTrack } from "@livekit/react-native";
import { Track } from "livekit-client";
import { useEffect } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";

registerGlobals();

export function LiveCall({ details, onEnd }: { details: CallJoinDetails; onEnd: () => void }) {
  const tokenRequest = trpc.calls.createToken.useMutation();
  const { e2eeManager } = useRNE2EEManager({ sharedKey: details.encryptionKey });

  useEffect(() => {
    void AudioSession.startAudioSession();
    tokenRequest.mutate({ roomId: details.roomId, callId: details.callId, participantId: details.participantId });
    return () => {
      AudioSession.stopAudioSession();
    };
  }, []);

  if (tokenRequest.isError) {
    return (
      <CallStatus
        title="تعذر بدء المكالمة"
        copy={tokenRequest.error.message || "تحقق من اتصالك ثم حاول مرة أخرى."}
        onEnd={onEnd}
      />
    );
  }
  if (!tokenRequest.data) return <CallStatus title="جارٍ تأمين المكالمة" copy="يُنشئ الخادم رمز اتصال قصير العمر دون كشف مفاتيح مشروع المكالمات." onEnd={onEnd} />;

  return (
    <LiveKitRoom
      serverUrl={tokenRequest.data.serverUrl}
      token={tokenRequest.data.token}
      connect
      audio
      video
      options={{ encryption: { e2eeManager } }}
      onDisconnected={onEnd}
      onError={() => undefined}
    >
      <CallRoom onEnd={onEnd} />
    </LiveKitRoom>
  );
}

function CallStatus({ title, copy, onEnd }: { title: string; copy: string; onEnd: () => void }) {
  return (
    <View style={styles.statusPage}>
      <ActivityIndicator color="#29B6D8" />
      <Text style={styles.statusTitle}>{title}</Text>
      <Text style={styles.statusCopy}>{copy}</Text>
      <Pressable onPress={onEnd} style={styles.leaveButton}><Text style={styles.leaveText}>إلغاء</Text></Pressable>
    </View>
  );
}

function CallRoom({ onEnd }: { onEnd: () => void }) {
  const room = useRoomContext();
  const { localParticipant, isCameraEnabled, isMicrophoneEnabled } = useLocalParticipant();
  const tracks = useTracks([Track.Source.Camera], { onlySubscribed: false });
  const remoteTrack = tracks.find(
    (track) => isTrackReference(track) && track.participant.identity !== localParticipant.identity,
  );

  const leave = () => {
    room.disconnect();
    onEnd();
  };

  return (
    <View style={styles.callPage}>
      {remoteTrack && isTrackReference(remoteTrack) ? (
        <VideoTrack trackRef={remoteTrack} style={styles.remoteVideo} />
      ) : (
        <View style={styles.waitingVideo}>
          <Text style={styles.waitingTitle}>المكالمة مشفرة</Text>
          <Text style={styles.waitingCopy}>بانتظار انضمام الطرف الآخر وتشغيل الكاميرا.</Text>
        </View>
      )}
      <View style={styles.callTop}><Text style={styles.encryptionBadge}>صوت وصورة مشفّران بين الطرفين</Text></View>
      <View style={styles.controls}>
        <Pressable onPress={() => void localParticipant.setMicrophoneEnabled(!isMicrophoneEnabled)} style={styles.controlButton}>
          <Text style={styles.controlText}>{isMicrophoneEnabled ? "كتم الصوت" : "تشغيل الصوت"}</Text>
        </Pressable>
        <Pressable onPress={() => void localParticipant.setCameraEnabled(!isCameraEnabled)} style={styles.controlButton}>
          <Text style={styles.controlText}>{isCameraEnabled ? "إيقاف الكاميرا" : "تشغيل الكاميرا"}</Text>
        </Pressable>
        <Pressable onPress={leave} style={styles.endButton}><Text style={styles.endText}>إنهاء</Text></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  callPage: { flex: 1, backgroundColor: "#061019" },
  statusPage: { flex: 1, backgroundColor: "#0A1420", alignItems: "center", justifyContent: "center", padding: 28 },
  statusTitle: { color: "#F3F8FC", fontSize: 21, fontWeight: "800", marginTop: 16 },
  statusCopy: { color: "#9FB5C6", fontSize: 14, lineHeight: 22, textAlign: "center", marginTop: 8 },
  waitingVideo: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30 },
  waitingTitle: { color: "#F3F8FC", fontSize: 22, fontWeight: "800" },
  waitingCopy: { color: "#9FB5C6", textAlign: "center", lineHeight: 22, marginTop: 9 },
  remoteVideo: { flex: 1, width: "100%" },
  callTop: { position: "absolute", top: 52, left: 18, right: 18, alignItems: "center" },
  encryptionBadge: { color: "#D8F5FB", backgroundColor: "#132537DD", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 14, fontSize: 12, overflow: "hidden" },
  controls: { position: "absolute", bottom: 42, left: 18, right: 18, flexDirection: "row-reverse", justifyContent: "center", gap: 9 },
  controlButton: { backgroundColor: "#19354A", paddingHorizontal: 14, minHeight: 48, borderRadius: 16, justifyContent: "center" },
  controlText: { color: "#F3F8FC", fontSize: 13, fontWeight: "700" },
  endButton: { backgroundColor: "#D65662", paddingHorizontal: 18, minHeight: 48, borderRadius: 16, justifyContent: "center" },
  endText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  leaveButton: { marginTop: 24, paddingHorizontal: 20, minHeight: 46, borderRadius: 14, justifyContent: "center", backgroundColor: "#234157" },
  leaveText: { color: "#F3F8FC", fontWeight: "800" },
});
