import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { AppLockSettings } from "@/components/app-lock-settings";
import { LiveCall } from "@/components/live-call";
import { ScreenContainer } from "@/components/screen-container";
import { useChat } from "@/lib/chat/chat-provider";
import type { CallJoinDetails } from "@/lib/chat/types";
import { hasLongPendingMessage, isMessageLongPending } from "@/lib/chat/message-status";
import { useCallNotifications } from "@/hooks/use-call-notifications";
import { Platform } from "react-native";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

type ViewMode = "home" | "create" | "join" | "chat" | "security" | "appLockSettings" | "call";

function tapFeedback() {
  if (Platform.OS !== "web") void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

function formatTime(value: number) {
  return new Intl.DateTimeFormat("ar", { hour: "2-digit", minute: "2-digit" }).format(value);
}

function PrimaryButton({ label, onPress, disabled = false }: { label: string; onPress: () => void; disabled?: boolean }) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={() => {
        tapFeedback();
        onPress();
      }}
      style={({ pressed }) => [styles.primaryButton, (disabled || pressed) && styles.primaryButtonPressed]}
    >
      <Text style={styles.primaryButtonText}>{label}</Text>
    </Pressable>
  );
}

export default function HomeScreen() {
  const {
    ready,
    session,
    messages,
    connection,
    peerIsTyping,
    incomingCall,
    error,
    safetyNumber,
    createSession,
    joinSession,
    sendMessage,
    retryMessage,
    deletePendingMessage,
    setTyping,
    markIncomingMessagesRead,
    beginCall,
    acceptIncomingCall,
    dismissIncomingCall,
    endCall,
    confirmSafetyNumber,
    clearSession,
    dismissError,
  } = useChat();
  const [viewMode, setViewMode] = useState<ViewMode>(session ? "chat" : "home");
  const [inviteInput, setInviteInput] = useState("");
  const [draft, setDraft] = useState("");
  const [working, setWorking] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [activeCall, setActiveCall] = useState<CallJoinDetails | null>(null);
  const { state: notificationState, reason: notificationReason, enableNotifications, sendIncomingCallNotice, unregisterForRoom } = useCallNotifications(session?.roomId);
  const listRef = useRef<FlatList>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const connectionLabel = useMemo(
    () => (connection === "connected" ? "القناة متصلة" : connection === "connecting" ? "جارٍ الاتصال" : "غير متصل"),
    [connection],
  );
  const hasPendingDelivery = useMemo(() => hasLongPendingMessage(messages, now), [messages, now]);

  useEffect(() => {
    if (ready && session && viewMode === "home") setViewMode("chat");
  }, [ready, session, viewMode]);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 5000);
    return () => clearInterval(timer);
  }, []);

  const copy = async (value: string, confirmation: string) => {
    await Clipboard.setStringAsync(value);
    if (Platform.OS !== "web") void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("تم النسخ", confirmation);
  };

  const handleCreate = async () => {
    setWorking(true);
    try {
      await createSession();
      setViewMode("create");
    } catch (exception) {
      Alert.alert("تعذر إنشاء الجلسة", exception instanceof Error ? exception.message : "حاول مرة أخرى.");
    } finally {
      setWorking(false);
    }
  };

  const handleJoin = async () => {
    setWorking(true);
    try {
      await joinSession(inviteInput);
      setViewMode("chat");
    } catch (exception) {
      Alert.alert("دعوة غير صالحة", exception instanceof Error ? exception.message : "تحقق من الدعوة ثم أعد المحاولة.");
    } finally {
      setWorking(false);
    }
  };

  const handleSend = async () => {
    if (!draft.trim()) return;
    try {
      await sendMessage(draft);
      setDraft("");
      setTyping(false);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
    } catch (exception) {
      Alert.alert("لم تُرسل الرسالة", exception instanceof Error ? exception.message : "تحقق من الاتصال.");
    }
  };

  const handleDraftChange = (value: string) => {
    setDraft(value);
    setTyping(Boolean(value.trim()));
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    if (value.trim()) {
      typingTimeoutRef.current = setTimeout(() => setTyping(false), 1700);
    }
  };

  const handleRetry = async (messageId: string) => {
    try {
      await retryMessage(messageId);
      if (Platform.OS !== "web") void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (exception) {
      Alert.alert("تعذرت إعادة المحاولة", exception instanceof Error ? exception.message : "تحقق من اتصالك ثم أعد المحاولة.");
    }
  };

  const handleDeletePending = (messageId: string) => {
    Alert.alert(
      "حذف الرسالة محليًا؟",
      "سيُحذف النص من هذا الجهاز ولن تظهر الرسالة هنا. لا يمكن سحب حزمة سبق وصولها إلى جهاز الطرف الآخر.",
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "حذف محليًا",
          style: "destructive",
          onPress: () => {
            void deletePendingMessage(messageId).catch((exception) =>
              Alert.alert("تعذر الحذف", exception instanceof Error ? exception.message : "حاول مرة أخرى."),
            );
          },
        },
      ],
    );
  };

  const handleStartCall = () => {
    if (!session?.verified) {
      Alert.alert("تحقق من رقم الأمان أولًا", "قارن رقم الأمان مع الطرف الآخر قبل بدء مكالمة خاصة.");
      return;
    }
    try {
      const call = beginCall();
      setActiveCall(call);
      void sendIncomingCallNotice(call.roomId);
      setViewMode("call");
    } catch (exception) {
      Alert.alert("تعذر بدء المكالمة", exception instanceof Error ? exception.message : "تحقق من اتصالك ثم أعد المحاولة.");
    }
  };

  const handleAcceptCall = () => {
    if (!session?.verified) {
      Alert.alert("تحقق من رقم الأمان أولًا", "لا تبدأ مكالمة قبل التحقق من هوية الطرف الآخر.");
      return;
    }
    try {
      setActiveCall(acceptIncomingCall());
      setViewMode("call");
    } catch (exception) {
      Alert.alert("تعذر الرد", exception instanceof Error ? exception.message : "حاول مرة أخرى.");
    }
  };

  const handleEndCall = () => {
    if (activeCall) endCall(activeCall.callId);
    setActiveCall(null);
    setViewMode("chat");
  };

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      setTyping(false);
    };
  }, [setTyping]);

  useEffect(() => {
    if (viewMode !== "chat" || !session?.peerPublicKey || !messages.length) return;
    const timer = setTimeout(() => void markIncomingMessagesRead(), 250);
    return () => clearTimeout(timer);
  }, [markIncomingMessagesRead, messages.length, session?.peerPublicKey, viewMode]);

  const handleClear = () => {
    Alert.alert("إنهاء الجلسة؟", "سيُحذف سجل المحادثة ومفاتيحها من هذا الجهاز فقط.", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف البيانات",
        style: "destructive",
        onPress: () => {
          void (async () => {
            await unregisterForRoom(session?.roomId);
            await clearSession();
          })();
          setViewMode("home");
          setInviteInput("");
          setDraft("");
        },
      },
    ]);
  };

  if (!ready) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator color="#29B6D8" />
        <Text style={styles.loadingText}>يُجهّز المساحة الخاصة…</Text>
      </ScreenContainer>
    );
  }

  if ((!session && viewMode !== "join" && viewMode !== "appLockSettings") || viewMode === "home") {
    return (
      <ScreenContainer className="px-6 py-7" edges={["top", "left", "right", "bottom"]}>
        <View style={styles.heroIcon}>
          <IconSymbol name="lock.fill" size={42} color="#29B6D8" />
        </View>
        <Text style={styles.brand}>همس</Text>
        <Text style={styles.subtitle}>محادثة خاصة بين شخصين، تُشفّر قبل أن تغادر جهازك.</Text>
        <View style={styles.privacyCard}>
          <IconSymbol name="shield.fill" size={21} color="#43D3A0" />
          <View style={styles.privacyTextWrap}>
            <Text style={styles.privacyTitle}>محتوى الرسائل لا يُخزّن في الخادم</Text>
            <Text style={styles.privacyCopy}>تحتفظ أجهزتك بالمفاتيح والسجل محليًا، بينما تمر الحزم المشفرة عبر القناة فقط.</Text>
          </View>
        </View>
        <View style={styles.homeActions}>
          <PrimaryButton label="إنشاء جلسة خاصة" onPress={handleCreate} disabled={working} />
          <Pressable style={({ pressed }) => [styles.secondaryButton, pressed && styles.secondaryPressed]} onPress={() => setViewMode("join")}>
            <IconSymbol name="message.fill" size={20} color="#29B6D8" />
            <Text style={styles.secondaryButtonText}>لدي دعوة للانضمام</Text>
          </Pressable>
          <Pressable style={({ pressed }) => [styles.appLockLink, pressed && styles.secondaryPressed]} onPress={() => setViewMode("appLockSettings")}>
            <IconSymbol name="lock.fill" size={17} color="#9FB5C6" />
            <Text style={styles.appLockLinkText}>قفل التطبيق</Text>
          </Pressable>
        </View>
        <Text style={styles.footerNote}>لا حسابات، ولا أرقام هواتف، ولا مزامنة سحابية.</Text>
      </ScreenContainer>
    );
  }

  if (viewMode === "join") {
    return (
      <ScreenContainer className="px-6 py-6" edges={["top", "left", "right", "bottom"]}>
        <Pressable onPress={() => setViewMode("home")} style={styles.backButton}>
          <Text style={styles.backText}>إلغاء</Text>
        </Pressable>
        <View style={styles.formHeader}>
          <View style={styles.smallIconWrap}><IconSymbol name="message.fill" size={27} color="#29B6D8" /></View>
          <Text style={styles.formTitle}>انضم إلى جلسة</Text>
          <Text style={styles.formCopy}>الصق دعوة «همس» التي استلمتها من الطرف الآخر. لا تكشف الدعوة محتوى الرسائل.</Text>
        </View>
        <TextInput
          value={inviteInput}
          onChangeText={setInviteInput}
          multiline
          autoCapitalize="none"
          autoCorrect={false}
          placeholder="الصق دعوة الجلسة هنا"
          placeholderTextColor="#7890A3"
          textAlign="left"
          style={styles.inviteInput}
        />
        <PrimaryButton label={working ? "جارٍ الانضمام…" : "انضمام آمن"} onPress={handleJoin} disabled={working || !inviteInput.trim()} />
        <Text style={styles.helperText}>بعد الاتصال، قارِن رقم الأمان مع الطرف الآخر عبر وسيلة مستقلة.</Text>
      </ScreenContainer>
    );
  }

  if (viewMode === "appLockSettings") {
    return (
      <ScreenContainer className="py-4" edges={["top", "left", "right", "bottom"]}>
        <Pressable onPress={() => setViewMode(session ? "chat" : "home")} style={styles.settingsBackButton}>
          <Text style={styles.backText}>العودة</Text>
        </Pressable>
        <AppLockSettings onBack={() => setViewMode(session ? "chat" : "home")} />
      </ScreenContainer>
    );
  }

  if (!session) return null;

  if (viewMode === "call" && activeCall) {
    return <LiveCall details={activeCall} onEnd={handleEndCall} />;
  }

  if (viewMode === "create") {
    return (
      <ScreenContainer className="px-6 py-6" edges={["top", "left", "right", "bottom"]}>
        <Pressable onPress={() => setViewMode("chat")} style={styles.backButton}>
          <Text style={styles.backText}>فتح المحادثة</Text>
        </Pressable>
        <View style={styles.formHeader}>
          <View style={styles.smallIconWrap}><IconSymbol name="plus.circle.fill" size={29} color="#29B6D8" /></View>
          <Text style={styles.formTitle}>أرسل الدعوة للطرف الآخر</Text>
          <Text style={styles.formCopy}>تتضمن الدعوة رمز الجلسة والمفتاح العام فقط. أرسلها عبر قناة تثق بها.</Text>
        </View>
        <View style={styles.codeCard}>
          <Text selectable style={styles.codeText}>{session.invite}</Text>
        </View>
        <Pressable style={({ pressed }) => [styles.copyButton, pressed && styles.secondaryPressed]} onPress={() => void copy(session.invite, "يمكنك الآن إرسال الدعوة إلى الطرف الآخر.")}>
          <IconSymbol name="doc.on.doc" size={19} color="#29B6D8" />
          <Text style={styles.copyText}>نسخ الدعوة</Text>
        </Pressable>
        <View style={styles.waitingBlock}>
          <ActivityIndicator color="#43D3A0" size="small" />
          <Text style={styles.waitingText}>بانتظار انضمام الطرف الثاني عبر هذه الدعوة.</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (viewMode === "security") {
    return (
      <ScreenContainer className="px-6 py-6" edges={["top", "left", "right", "bottom"]}>
        <Pressable onPress={() => setViewMode("chat")} style={styles.backButton}><Text style={styles.backText}>العودة للمحادثة</Text></Pressable>
        <View style={styles.formHeader}>
          <View style={styles.smallIconWrap}><IconSymbol name="shield.fill" size={29} color="#43D3A0" /></View>
          <Text style={styles.formTitle}>أمان الجلسة</Text>
          <Text style={styles.formCopy}>قارِن هذا الرقم مع الطرف الآخر شفهيًا أو وجهًا لوجه قبل اعتبار الهوية متحققة.</Text>
        </View>
        <View style={[styles.safetyCard, session.verified && styles.safetyCardVerified]}>
          <Text style={styles.safetyLabel}>رقم الأمان</Text>
          <Text selectable style={styles.safetyNumber}>{safetyNumber ?? "في انتظار الطرف الآخر"}</Text>
          <Text style={styles.safetyCaption}>{session.verified ? "تم تأكيده على هذا الجهاز" : "لم يُؤكّد بعد"}</Text>
        </View>
        <Pressable disabled={!safetyNumber} style={({ pressed }) => [styles.copyButton, (!safetyNumber || pressed) && styles.secondaryPressed]} onPress={() => safetyNumber && void copy(safetyNumber, "أرسله أو قارنه خارج التطبيق.")}>
          <IconSymbol name="doc.on.doc" size={19} color="#29B6D8" />
          <Text style={styles.copyText}>نسخ رقم الأمان</Text>
        </Pressable>
        {!session.verified && <PrimaryButton label="تحققت من الرقم" onPress={() => void confirmSafetyNumber()} disabled={!safetyNumber} />}
        <Pressable onPress={handleClear} style={styles.destructiveButton}>
          <IconSymbol name="trash.fill" size={18} color="#FF8E98" />
          <Text style={styles.destructiveText}>حذف السجل والمفاتيح محليًا</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <KeyboardAvoidingView style={styles.chatContainer} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={70}>
        <View style={styles.chatHeader}>
          <View>
            <Text style={styles.chatTitle}>محادثة خاصة</Text>
            <View style={styles.statusRow}>
              <View style={[styles.statusDot, connection === "connected" ? styles.statusConnected : styles.statusIdle]} />
              <Text style={styles.statusText}>{connectionLabel}</Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            <Pressable accessibilityLabel="بدء مكالمة فيديو وصوت" onPress={handleStartCall} style={({ pressed }) => [styles.callButton, pressed && styles.secondaryPressed]}>
              <IconSymbol name="video.fill" size={21} color="#0A1420" />
            </Pressable>
            <Pressable accessibilityLabel="قفل التطبيق" onPress={() => setViewMode("appLockSettings")} style={({ pressed }) => [styles.securityButton, pressed && styles.secondaryPressed]}>
              <IconSymbol name="lock.fill" size={20} color="#9FB5C6" />
            </Pressable>
            <Pressable accessibilityLabel="أمان الجلسة" onPress={() => setViewMode("security")} style={({ pressed }) => [styles.securityButton, pressed && styles.secondaryPressed]}>
              <IconSymbol name={session.verified ? "checkmark.seal.fill" : "shield.fill"} size={23} color={session.verified ? "#43D3A0" : "#F4B860"} />
            </Pressable>
          </View>
        </View>
        {!session.peerPublicKey ? (
          <View style={styles.emptyChat}>
            <IconSymbol name="wifi" size={32} color="#9FB5C6" />
            <Text style={styles.emptyTitle}>بانتظار الطرف الآخر</Text>
            <Text style={styles.emptyCopy}>افتح شاشة الأمان أو ارجع لنسخ الدعوة ومشاركتها. لن تُرسل أي رسالة قبل اقتران المفتاحين.</Text>
            <Pressable onPress={() => setViewMode("create")} style={styles.inlineAction}><Text style={styles.inlineActionText}>عرض الدعوة</Text></Pressable>
          </View>
        ) : (
          <>
            {!session.verified && (
              <Pressable onPress={() => setViewMode("security")} style={styles.verificationBanner}>
                <IconSymbol name="shield.fill" size={18} color="#F4B860" />
                <Text style={styles.verificationText}>تحقق من رقم الأمان قبل تبادل معلومات حساسة.</Text>
              </Pressable>
            )}
            {notificationState !== "enabled" && (
              <View style={styles.notificationsCard}>
                <View style={styles.notificationsCopy}>
                  <Text style={styles.notificationsTitle}>تنبيهات المكالمات</Text>
                  <Text style={styles.notificationsText}>لتتلقى مكالمة عند إغلاق التطبيق، فعّل تنبيهًا عامًا لا يعرض الرسائل.</Text>
                  {notificationReason && <Text style={styles.notificationsReason}>{notificationReason}</Text>}
                </View>
                <Pressable disabled={notificationState === "enabling"} onPress={() => void enableNotifications()} style={({ pressed }) => [styles.notificationEnableButton, (pressed || notificationState === "enabling") && styles.retryButtonDisabled]}>
                  <Text style={styles.notificationEnableText}>{notificationState === "enabling" ? "جارٍ التفعيل" : "تفعيل"}</Text>
                </Pressable>
              </View>
            )}
            {hasPendingDelivery && (
              <View style={styles.deliveryAlert} accessibilityRole="alert">
                <IconSymbol name="wifi" size={18} color="#F4B860" />
                <View style={styles.deliveryAlertCopy}>
                  <Text style={styles.deliveryAlertTitle}>رسالة بانتظار التسليم</Text>
                  <Text style={styles.deliveryAlertText}>{connection === "connected" ? "لم يؤكد جهاز الطرف الآخر استلامها بعد." : "تحقق من اتصالك بالإنترنت ثم انتظر إعادة الاتصال."}</Text>
                </View>
              </View>
            )}
            <FlatList
              ref={listRef}
              data={messages}
              keyExtractor={(item) => item.id}
              contentContainerStyle={messages.length ? styles.messagesList : styles.messagesEmptyList}
              onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
              ListEmptyComponent={<Text style={styles.noMessages}>ابدآ الحديث. ستُشفّر كل رسالة على الجهاز قبل إرسالها.</Text>}
              renderItem={({ item }) => (
                <View style={[styles.messageBubble, item.direction === "outgoing" ? styles.outgoingBubble : styles.incomingBubble]}>
                  <Text style={[styles.messageText, item.direction === "outgoing" && styles.outgoingText]}>{item.text}</Text>
                  <View style={styles.messageMeta}>
                    <Text style={[styles.messageTime, item.direction === "outgoing" && styles.outgoingTime]}>{formatTime(item.sentAt)}</Text>
                    {item.direction === "outgoing" && <Text style={[styles.receiptText, item.status === "read" && styles.receiptRead]}>{item.status === "read" ? "قُرئت" : item.status === "delivered" ? "تم التسليم" : "أُرسلت"}</Text>}
                  </View>
                  {isMessageLongPending(item, now) && (
                    <View style={styles.pendingActions}>
                      <Pressable
                        disabled={connection !== "connected"}
                        onPress={() => {
                          tapFeedback();
                          void handleRetry(item.id);
                        }}
                        style={({ pressed }) => [styles.retryButton, (pressed || connection !== "connected") && styles.retryButtonDisabled]}
                      >
                        <IconSymbol name="paperplane.fill" size={14} color="#0A1420" />
                        <Text style={styles.retryButtonText}>{connection === "connected" ? "إعادة المحاولة" : "بانتظار الاتصال"}</Text>
                      </Pressable>
                      <Pressable onPress={() => handleDeletePending(item.id)} style={({ pressed }) => [styles.deletePendingButton, pressed && styles.deletePendingButtonPressed]}>
                        <IconSymbol name="trash.fill" size={13} color="#15596A" />
                        <Text style={styles.deletePendingText}>حذف محليًا</Text>
                      </Pressable>
                    </View>
                  )}
                </View>
              )}
            />
            <View style={styles.typingArea}>
              {peerIsTyping && (
                <View style={styles.typingIndicator}>
                  <View style={[styles.typingDot, styles.typingDotOne]} />
                  <View style={[styles.typingDot, styles.typingDotTwo]} />
                  <View style={[styles.typingDot, styles.typingDotThree]} />
                  <Text style={styles.typingText}>الطرف الآخر يكتب</Text>
                </View>
              )}
            </View>
          </>
        )}
        {session.peerPublicKey && (
          <View style={styles.composer}>
            <TextInput
              value={draft}
              onChangeText={handleDraftChange}
              placeholder="اكتب رسالة خاصة"
              placeholderTextColor="#7890A3"
              style={styles.messageInput}
              multiline
              maxLength={1500}
              textAlign="right"
              returnKeyType="send"
              onSubmitEditing={() => void handleSend()}
            />
            <Pressable accessibilityLabel="إرسال الرسالة" onPress={() => void handleSend()} disabled={!draft.trim() || connection !== "connected"} style={({ pressed }) => [styles.sendButton, (!draft.trim() || connection !== "connected" || pressed) && styles.sendButtonDisabled]}>
              <IconSymbol name="paperplane.fill" size={20} color="#0A1420" />
            </Pressable>
          </View>
        )}
      </KeyboardAvoidingView>
      {error && (
        <Pressable onPress={dismissError} style={styles.errorToast}>
          <Text style={styles.errorText}>{error}</Text>
          <IconSymbol name="xmark.circle.fill" size={19} color="#FF8E98" />
        </Pressable>
      )}
      {incomingCall && !activeCall && (
        <View style={styles.incomingCallCard} accessibilityRole="alert">
          <View style={styles.incomingCallIcon}><IconSymbol name="video.fill" size={21} color="#29B6D8" /></View>
          <View style={styles.incomingCallCopy}>
            <Text style={styles.incomingCallTitle}>مكالمة فيديو واردة</Text>
            <Text style={styles.incomingCallText}>تصل دعوة المكالمة عبر القناة المشفرة للجلسة.</Text>
          </View>
          <View style={styles.incomingCallActions}>
            <Pressable onPress={handleAcceptCall} style={styles.answerButton}><Text style={styles.answerText}>رد</Text></Pressable>
            <Pressable onPress={() => { endCall(incomingCall.callId); dismissIncomingCall(); }} style={styles.declineButton}><Text style={styles.declineText}>رفض</Text></Pressable>
          </View>
        </View>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  loadingText: { color: "#9FB5C6", marginTop: 14, fontSize: 15 },
  heroIcon: { alignSelf: "center", backgroundColor: "#132537", width: 88, height: 88, borderRadius: 28, alignItems: "center", justifyContent: "center", marginTop: 38 },
  brand: { color: "#F3F8FC", fontSize: 38, fontWeight: "800", textAlign: "center", marginTop: 20 },
  subtitle: { color: "#9FB5C6", fontSize: 17, lineHeight: 27, textAlign: "center", marginTop: 10, paddingHorizontal: 10 },
  privacyCard: { flexDirection: "row-reverse", gap: 12, backgroundColor: "#132537", borderColor: "#234157", borderWidth: 1, borderRadius: 20, padding: 16, marginTop: 35 },
  privacyTextWrap: { flex: 1, alignItems: "flex-end" },
  privacyTitle: { color: "#F3F8FC", textAlign: "right", fontWeight: "700", fontSize: 14 },
  privacyCopy: { color: "#9FB5C6", textAlign: "right", fontSize: 13, lineHeight: 20, marginTop: 5 },
  homeActions: { marginTop: "auto", gap: 12 },
  primaryButton: { backgroundColor: "#29B6D8", minHeight: 54, borderRadius: 17, alignItems: "center", justifyContent: "center", paddingHorizontal: 20 },
  primaryButtonPressed: { opacity: 0.58, transform: [{ scale: 0.98 }] },
  primaryButtonText: { color: "#0A1420", fontSize: 16, fontWeight: "800" },
  secondaryButton: { minHeight: 52, borderRadius: 17, borderColor: "#234157", borderWidth: 1, flexDirection: "row-reverse", gap: 9, alignItems: "center", justifyContent: "center" },
  secondaryPressed: { opacity: 0.65 },
  secondaryButtonText: { color: "#D3E3EC", fontSize: 15, fontWeight: "700" },
  appLockLink: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, minHeight: 38 },
  appLockLinkText: { color: "#9FB5C6", fontSize: 13, fontWeight: "700" },
  footerNote: { color: "#7890A3", textAlign: "center", fontSize: 12, marginTop: 18, marginBottom: 5 },
  backButton: { alignSelf: "flex-start", paddingVertical: 8, paddingHorizontal: 3 },
  settingsBackButton: { alignSelf: "flex-start", paddingVertical: 8, paddingHorizontal: 24 },
  backText: { color: "#29B6D8", fontSize: 15, fontWeight: "700" },
  formHeader: { alignItems: "flex-end", marginTop: 24 },
  smallIconWrap: { backgroundColor: "#132537", width: 52, height: 52, borderRadius: 17, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  formTitle: { color: "#F3F8FC", fontSize: 26, fontWeight: "800", textAlign: "right" },
  formCopy: { color: "#9FB5C6", fontSize: 15, lineHeight: 24, textAlign: "right", marginTop: 9 },
  inviteInput: { color: "#F3F8FC", borderColor: "#234157", borderWidth: 1, backgroundColor: "#132537", minHeight: 150, borderRadius: 18, padding: 15, fontSize: 14, lineHeight: 21, marginTop: 27, marginBottom: 14, writingDirection: "ltr" },
  helperText: { color: "#7890A3", textAlign: "center", fontSize: 13, lineHeight: 20, marginTop: 18, paddingHorizontal: 15 },
  codeCard: { backgroundColor: "#132537", borderColor: "#234157", borderWidth: 1, borderRadius: 18, padding: 16, marginTop: 28 },
  codeText: { color: "#D8F5FB", fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), fontSize: 13, lineHeight: 21, textAlign: "left", writingDirection: "ltr" },
  copyButton: { flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 9, minHeight: 50, borderColor: "#234157", borderWidth: 1, borderRadius: 16, marginTop: 12 },
  copyText: { color: "#29B6D8", fontSize: 15, fontWeight: "700" },
  waitingBlock: { flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 10, marginTop: 28 },
  waitingText: { color: "#9FB5C6", fontSize: 14 },
  safetyCard: { alignItems: "center", padding: 24, borderRadius: 20, backgroundColor: "#132537", borderColor: "#F4B860", borderWidth: 1, marginTop: 27 },
  safetyCardVerified: { borderColor: "#43D3A0" },
  safetyLabel: { color: "#9FB5C6", fontSize: 13, fontWeight: "700" },
  safetyNumber: { color: "#F3F8FC", fontSize: 20, lineHeight: 32, letterSpacing: 1.3, fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }), textAlign: "center", marginTop: 10 },
  safetyCaption: { color: "#F4B860", fontSize: 13, marginTop: 12 },
  destructiveButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, minHeight: 48, marginTop: 24 },
  destructiveText: { color: "#FF8E98", fontWeight: "700", fontSize: 14 },
  chatContainer: { flex: 1 },
  chatHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 12, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: "#234157" },
  chatTitle: { color: "#F3F8FC", fontSize: 19, fontWeight: "800", textAlign: "left" },
  statusRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 5 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusConnected: { backgroundColor: "#43D3A0" },
  statusIdle: { backgroundColor: "#F4B860" },
  statusText: { color: "#9FB5C6", fontSize: 12 },
  securityButton: { backgroundColor: "#132537", width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  callButton: { backgroundColor: "#29B6D8", width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  headerActions: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  verificationBanner: { marginHorizontal: 16, marginTop: 12, backgroundColor: "#2A271D", borderRadius: 14, padding: 12, flexDirection: "row-reverse", gap: 9, alignItems: "center" },
  verificationText: { color: "#F8D6A0", fontSize: 13, flex: 1, textAlign: "right", lineHeight: 19 },
  notificationsCard: { marginHorizontal: 16, marginTop: 10, borderRadius: 14, backgroundColor: "#102638", borderWidth: 1, borderColor: "#1E6178", padding: 12, flexDirection: "row-reverse", gap: 12, alignItems: "center" },
  notificationsCopy: { flex: 1, alignItems: "flex-end" },
  notificationsTitle: { color: "#D8F5FB", fontSize: 13, fontWeight: "800", textAlign: "right" },
  notificationsText: { color: "#9FB5C6", fontSize: 11, lineHeight: 16, textAlign: "right", marginTop: 3 },
  notificationsReason: { color: "#F4B860", fontSize: 10, lineHeight: 15, textAlign: "right", marginTop: 5 },
  notificationEnableButton: { minHeight: 33, paddingHorizontal: 11, borderRadius: 10, backgroundColor: "#29B6D8", justifyContent: "center" },
  notificationEnableText: { color: "#0A1420", fontSize: 11, fontWeight: "800" },
  deliveryAlert: { marginHorizontal: 16, marginTop: 10, borderRadius: 14, backgroundColor: "#2A271D", borderWidth: 1, borderColor: "#6B552B", padding: 12, flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  deliveryAlertCopy: { flex: 1, alignItems: "flex-end" },
  deliveryAlertTitle: { color: "#F8D6A0", fontSize: 13, fontWeight: "800", textAlign: "right" },
  deliveryAlertText: { color: "#D4C69F", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 2 },
  messagesList: { padding: 16, gap: 9 },
  messagesEmptyList: { flexGrow: 1, justifyContent: "center", padding: 32 },
  noMessages: { color: "#7890A3", textAlign: "center", fontSize: 15, lineHeight: 24 },
  messageBubble: { maxWidth: "81%", borderRadius: 18, paddingHorizontal: 13, paddingVertical: 10 },
  outgoingBubble: { alignSelf: "flex-end", backgroundColor: "#29B6D8", borderBottomRightRadius: 5 },
  incomingBubble: { alignSelf: "flex-start", backgroundColor: "#132537", borderBottomLeftRadius: 5 },
  messageText: { color: "#E8F1F6", fontSize: 16, lineHeight: 23, textAlign: "right", writingDirection: "rtl" },
  outgoingText: { color: "#0A1420" },
  messageTime: { color: "#9FB5C6", alignSelf: "flex-end", fontSize: 10, marginTop: 5 },
  outgoingTime: { color: "#15596A" },
  messageMeta: { flexDirection: "row-reverse", alignSelf: "flex-end", alignItems: "center", gap: 6, marginTop: 4 },
  receiptText: { color: "#15596A", fontSize: 10, fontWeight: "700" },
  receiptRead: { color: "#064C60" },
  retryButton: { alignSelf: "flex-end", marginTop: 8, minHeight: 30, paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#F4B860", flexDirection: "row-reverse", alignItems: "center", gap: 5, justifyContent: "center" },
  retryButtonDisabled: { opacity: 0.55 },
  retryButtonText: { color: "#0A1420", fontSize: 11, fontWeight: "800" },
  pendingActions: { alignSelf: "flex-end", flexDirection: "row-reverse", alignItems: "center", gap: 6, marginTop: 8 },
  deletePendingButton: { minHeight: 30, paddingHorizontal: 8, borderRadius: 10, backgroundColor: "#BBD5DE", flexDirection: "row-reverse", alignItems: "center", gap: 4, justifyContent: "center" },
  deletePendingButtonPressed: { opacity: 0.68 },
  deletePendingText: { color: "#15596A", fontSize: 11, fontWeight: "800" },
  typingArea: { minHeight: 32, justifyContent: "center", paddingHorizontal: 16 },
  typingIndicator: { alignSelf: "flex-start", flexDirection: "row-reverse", alignItems: "center", gap: 4, backgroundColor: "#132537", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7 },
  typingDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: "#29B6D8" },
  typingDotOne: { opacity: 0.45 },
  typingDotTwo: { opacity: 0.7 },
  typingDotThree: { opacity: 1 },
  typingText: { color: "#9FB5C6", fontSize: 12, marginRight: 3 },
  composer: { minHeight: 70, padding: 10, borderTopWidth: StyleSheet.hairlineWidth, borderColor: "#234157", flexDirection: "row-reverse", gap: 9, alignItems: "flex-end" },
  messageInput: { flex: 1, minHeight: 47, maxHeight: 110, backgroundColor: "#132537", borderRadius: 18, color: "#F3F8FC", fontSize: 16, paddingHorizontal: 14, paddingVertical: 11, writingDirection: "rtl" },
  sendButton: { width: 47, height: 47, borderRadius: 16, backgroundColor: "#29B6D8", alignItems: "center", justifyContent: "center" },
  sendButtonDisabled: { opacity: 0.45 },
  emptyChat: { flex: 1, justifyContent: "center", alignItems: "center", paddingHorizontal: 36 },
  emptyTitle: { color: "#F3F8FC", fontSize: 19, fontWeight: "800", marginTop: 14 },
  emptyCopy: { color: "#9FB5C6", fontSize: 15, lineHeight: 24, textAlign: "center", marginTop: 8 },
  inlineAction: { marginTop: 20, paddingVertical: 11, paddingHorizontal: 20, borderRadius: 14, borderColor: "#234157", borderWidth: 1 },
  inlineActionText: { color: "#29B6D8", fontWeight: "700" },
  errorToast: { position: "absolute", bottom: 78, left: 16, right: 16, borderRadius: 16, backgroundColor: "#40212A", borderWidth: 1, borderColor: "#8B3948", padding: 13, flexDirection: "row-reverse", gap: 10, alignItems: "center" },
  errorText: { color: "#FFD2D8", fontSize: 13, lineHeight: 19, textAlign: "right", flex: 1 },
  incomingCallCard: { position: "absolute", bottom: 82, left: 14, right: 14, borderRadius: 19, backgroundColor: "#132537", borderWidth: 1, borderColor: "#29B6D8", padding: 13, flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  incomingCallIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#173346", alignItems: "center", justifyContent: "center" },
  incomingCallCopy: { flex: 1, alignItems: "flex-end" },
  incomingCallTitle: { color: "#F3F8FC", fontSize: 14, fontWeight: "800", textAlign: "right" },
  incomingCallText: { color: "#9FB5C6", fontSize: 11, lineHeight: 16, textAlign: "right", marginTop: 3 },
  incomingCallActions: { gap: 6 },
  answerButton: { backgroundColor: "#43D3A0", minWidth: 48, height: 29, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  answerText: { color: "#073223", fontSize: 11, fontWeight: "800" },
  declineButton: { backgroundColor: "#40212A", minWidth: 48, height: 29, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  declineText: { color: "#FFB9C1", fontSize: 11, fontWeight: "800" },
});
